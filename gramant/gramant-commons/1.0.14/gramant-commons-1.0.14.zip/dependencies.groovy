grails.project.work.dir = "target"

grails.project.dependency.resolution = {
    inherits("global") {
        excludes "hsqldb"
    }
    log "debug" // log level of Ivy resolver, either 'error', 'warn', 'info', 'debug' or 'verbose'
    repositories {
        mavenRepo "http://maven.dev.intra/artifactory/repo"
//        grailsHome()
//        grailsCentral()
        mavenLocal()
        mavenCentral()
        mavenRepo "http://download.java.net/maven/2/"
    }
    dependencies {

        runtime 'com.ibm.icu:icu4j:4.4.1'

        // ATTENTION: replace with Spring version used by your project.
        // Potential problem here in that we may end up with a different version
        // during war deployment to product, but there is no solution right now.
        //
        // See: http://jira.codehaus.org/browse/GRAILS-7192
        // See: http://grails.1312388.n4.nabble.com/handling-Spring-dependencies-td3226874.html
        runtime 'org.springframework:spring-test:3.0.5.RELEASE'         // see GRAILSPLUGINS-1885 - required for WAR
        runtime 'org.apache.httpcomponents:httpclient:4.0'         // used by social API
        runtime 'com.yahoo.platform.yui:yuicompressor:2.4.2'
        runtime 'commons-codec:commons-codec:1.4'
    }
    plugins {
        runtime('org.grails.plugins:joda-time:1.2')
        runtime('org.grails.plugins:hibernate:latest')
    }
}

//if (appName == "grails-mail") {
//    // use for testing view resolution from plugins
//    grails.plugin.location.'for-plugin-view-resolution' = 'plugins/for-plugin-view-resolution'
//}