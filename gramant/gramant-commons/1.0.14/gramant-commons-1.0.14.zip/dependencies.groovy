grails.project.class.dir = "target/classes"
grails.project.test.class.dir = "target/test-classes"
grails.project.test.reports.dir = "target/test-reports"
//grails.project.war.file = "target/${appName}-${appVersion}.war"
grails.project.dependency.resolution = {
    // inherit Grails' default dependencies
    inherits("global") {
        excludes "hsqldb"
    }
    log "warn" // log level of Ivy resolver, either 'error', 'warn', 'info', 'debug' or 'verbose'
    repositories {

        mavenRepo "http://maven.dev.intra/artifactory/repo"

        grailsHome()
        grailsCentral()
        mavenLocal()
        mavenCentral()

        mavenRepo "https://raw.github.com/spn/maven-repo/master"
    }

    dependencies {
        // specify dependencies here under either 'build', 'compile', 'runtime', 'test' or 'provided' scopes eg.
        runtime 'gramant:gramant-hsqldb:2.0.0'
        runtime 'com.ibm.icu:icu4j:4.4.1'
        // will evict 1.3 dependency
        runtime 'commons-codec:commons-codec:1.4'
        // ATTENTION: replace with Spring version used by your project.
        runtime 'org.springframework:spring-test:3.0.5.RELEASE'         // see GRAILSPLUGINS-1885 - required for WAR
        runtime 'org.apache.httpcomponents:httpclient:4.1'         // used by social API
        runtime 'com.yahoo.platform.yui:yuicompressor:2.4.2'
    }

}
