/*
 * PlainTextCodec
 *
 * Copyright (c) 2009 Gramant. All Rights Reserved
 */

import org.codehaus.groovy.grails.plugins.codecs.HTMLCodec

/**
 * Converts plaintext content into HTML,
 * making sure newlines are converted to BRs.
 */
public class PlainTextCodec {

    /**
     * Encode a plaintext string.
     * @param target object to be encoded.
     * @return encoded string to valid HTML newlines.
     */
    public static String encode(Object target) {
        String encoded = HTMLCodec.encode(target)
        return encoded == null ? null : encoded.replace('\n', '<br/>')
    }
}
