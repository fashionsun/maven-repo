/*
 * RequestBundle
 *
 * Copyright (c) 2011 Gramant. All Rights Reserved
 */

import org.codehaus.groovy.grails.plugins.GrailsPluginManager;
import org.codehaus.groovy.grails.web.servlet.mvc.GrailsWebRequest;

import java.io.IOException;
import java.io.Writer;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Used for bundling JS/CSS resources, prevents duplicate requests.
 */
public class RequestBundle {

    private final Map<ResourceKey, Integer> javascripts = new LinkedHashMap<ResourceKey, Integer>();
    private final Map<ResourceKey, Integer> css = new LinkedHashMap<ResourceKey, Integer>();

    private final GrailsWebRequest request;
    private static final String IE7_ADDON_SUFFIX = "_ie7_addon";

    public RequestBundle(GrailsWebRequest request) {
        this.request = request;
    }

    private void register(Map<ResourceKey, Integer> cache, String src, String plugin, boolean ie7) {
        ResourceKey key = new ResourceKey(src, plugin, ie7);
        Integer deps;
        if (cache.containsKey(key)) {
            deps = cache.get(key);
        } else {
            deps = 0;
        }
        deps++;
        cache.put(key, deps);
    }


    public void registerJavascript(String src, String plugin, boolean ie7) {
        register(javascripts, src, plugin, ie7);
    }

    public void registerCSS(String src, String plugin, boolean ie7) {
        register(css, src, plugin, ie7);
    }

    public GrailsPluginManager getPluginManager() {
        return request.getApplicationContext().getBean("pluginManager", GrailsPluginManager.class);
    }

    public void renderJavascripts(String version) throws IOException {
        Writer out = request.getOut();
        for(ResourceKey key : javascripts.keySet()) {
            out.write("<script type=\"text/javascript\" src=\"");
            out.write(key.getURL("js", ".js"));
            if (version != null) {
                out.write("?rev="+version);
            }
            out.write("\"></script>\n");
        }
    }


    public void renderCSS(String version) throws IOException {
        Writer out = request.getOut();
        for(ResourceKey key : css.keySet()) {
            out.write("<link href=\"");
            out.write(key.getURL("css", ".css"));
            if (version != null) {
                out.write("?rev="+version);
            }
            out.write("\" media=\"screen\" rel=\"stylesheet\" type=\"text/css\" />\n");
            if (key.isIE7()) {
                // load IE7 addon script.
                out.write("\n<!--[if lte IE 7]>\n");
                out.write("<link href=\"");
                out.write(key.getURL("css", IE7_ADDON_SUFFIX + ".css"));
                out.write("\" media=\"screen\" rel=\"stylesheet\" type=\"text/css\" />\n");
                out.write("<![endif]-->\n");
            }
        }
    }

    private class ResourceKey {
        private String src;
        private String plugin;
        private boolean ie7;

        private ResourceKey(String src, String plugin, boolean ie7) {
            this.src = src;
            this.plugin = plugin;
            this.ie7 = ie7;
        }

        public boolean isIE7() {
            return ie7;
        }

        public String getPlugin() {
            return plugin;
        }


        public String getURL(String prefix, String suffix) {
            String baseUri = request.getAttributes().getApplicationUri(request.getCurrentRequest());
            StringBuilder uri = new StringBuilder(baseUri);
            if (plugin != null) {
                String pluginContextPath = getPluginManager().getPluginPath(plugin);
                uri.append(pluginContextPath);
                if (!pluginContextPath.endsWith("/")) {
                    uri.append('/');
                }
            } else {
                uri.append('/');
            }
            uri.append(prefix);
            if (!prefix.endsWith("/")) {
                uri.append('/');
            }
            uri.append(src);
            if (suffix != null) {
                uri.append(suffix);
            }
            return uri.toString();
        }


        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            ResourceKey that = (ResourceKey) o;

            if (ie7 != that.ie7) return false;
            if (plugin != null ? !plugin.equals(that.plugin) : that.plugin != null) return false;
            if (src != null ? !src.equals(that.src) : that.src != null) return false;

            return true;
        }

        @Override
        public int hashCode() {
            int result = src != null ? src.hashCode() : 0;
            result = 31 * result + (plugin != null ? plugin.hashCode() : 0);
            result = 31 * result + (ie7 ? 1 : 0);
            return result;
        }

        @Override
        public String toString() {
            return "ResourceKey{" +
                    "src='" + src + '\'' +
                    ", plugin='" + plugin + '\'' +
                    ", ie7=" + ie7 +
                    '}';
        }
    }
}
