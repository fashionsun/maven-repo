/*
* CustomFormatTagLib
* Copyright (c) 2011 Gramant
*/

import com.ibm.icu.text.SimpleDateFormat as SDF
import org.joda.time.LocalDate
import com.ibm.icu.util.ULocale as UL
import org.springframework.web.servlet.support.RequestContextUtils as RCU

/**
 * Date/time/text formatting tags.
 *
 */
public class CustomFormatTagLib {

    /** Uses fmt:xxxx namespace  */
    static namespace = 'fmt'

    /** i18n */
    def messageSource

    /**
     * Apply ICU4J formatting to JODA's LocalDate.
     */
    def formatSDF(String pattern, LocalDate dt) {
        def myLocale = UL.forLocale(RCU.getLocale(request))
        String result = new SDF(pattern, myLocale).format(dt.toDateTimeAtStartOfDay().toDate())
        return myLocale.getBaseName() == 'ru' ? result.toLowerCase() : result
    }
    
    /**
     * Format JODA objects as "1 July".
     */
    def formatMonth = {attrs ->
        if (!attrs.value) { return }
        def dt = attrs.value instanceof LocalDate ? attrs.value.toDateTimeAtStartOfDay().toDate() : attrs.value.toDate()
        def myLocale = UL.forLocale(RCU.getLocale(request))
        out << new SDF("d MMMM", myLocale).format(dt).toLowerCase()
    }

	/**
     * Format day-of-week, short
     */
    def formatDOW = { attrs ->
        if (!attrs.value) { return }
        def dt = attrs.value
        def useShort = attrs.short
        def str = formatSDF(useShort ? 'EE, d/MM' : 'EEEE, d MMMM', dt)
        out << str[0..0].toUpperCase() + str[1..<str.length()]
    }

    /**
     * Format JODA objects as "1 July 2009".
     */
    def formatMonthYear = {attrs ->
        if (!attrs.value) { return }
        def dt = attrs.value instanceof LocalDate ? attrs.value.toDateTimeAtStartOfDay().toDate() : attrs.value.toDate()
        def myLocale = UL.forLocale(RCU.getLocale(request))
        out << new SDF("d MMMM yyyy", myLocale).format(dt).toLowerCase()
    }

    def formatPlainDate = {attrs ->
        if (!attrs.value) { return }
        def dt = attrs.value instanceof LocalDate ? attrs.value.toDateTimeAtStartOfDay().toDate() : attrs.value.toDate()
        def myLocale = UL.forLocale(RCU.getLocale(request))
        out << new SDF("dd.MM.yyyy", myLocale).format(dt)
    }

    def time = {attrs ->
          if (!attrs.value) { return }
          def dt = attrs.value instanceof LocalDate ? attrs.value.toDateTimeAtStartOfDay().toDate() : attrs.value.toDate()
          def myLocale = UL.forLocale(RCU.getLocale(request))
          out << new SDF("HH:mm", myLocale).format(dt)
    }

    /**
     * Smart format JODA objects as [day month_name] if year is current or [day month_name year] otherwise.
     * Samples (current year is 2010): 19 march 2010 - "19 march"; 2 december 2009 - "2 december 2009"
     * If attrs.isYearRequired is true then the year will be inserted in any case
     */
    def smartFormatDate = { attrs ->
        if (!attrs.value) { return }
        def dt = attrs.value instanceof LocalDate ? attrs.value.toDateTimeAtStartOfDay().toDate() : attrs.value.toDate()
        def myLocale = UL.forLocale(RCU.getLocale(request))
        out << new SDF(attrs.isYearRequired || (dt.getYear() != new LocalDate().getYear()) ? "d MMMM yyyy" : "d MMMM", myLocale).format(dt)
    }

	/**
     * Smart format JODA objects as [month_name] if year is current or [month_name year] otherwise.
	 * Samples (current year is 2010): march 2010 - "March"; december 2009 - "December 2009"
	 * If attrs.isYearRequired is true then the year will be inserted in any case
     */
	def smartFormatMonthYear = { attrs ->
        if (!attrs.value) { return }
		def targetDate = attrs.remove('value') as LocalDate
		def msgcode = "month." + targetDate.getMonthOfYear()
		def locale = RCU.getLocale(request)
		def msg = messageSource.getMessage(msgcode, null, locale)
		out << msg

		if (attrs.isYearRequired || (targetDate.getYear() != new LocalDate().getYear())) {
			out << " " + targetDate.getYear()
		}
	}
    
}
