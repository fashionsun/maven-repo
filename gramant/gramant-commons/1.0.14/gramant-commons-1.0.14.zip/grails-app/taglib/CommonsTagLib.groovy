/*
* CommonsTagLib
*
* Copyright (c) 2010 Gramant. All Rights Reserved
*/

import org.springframework.web.servlet.support.RequestContextUtils as RCU
import com.ibm.icu.util.ULocale as UL
import com.ibm.icu.text.SimpleDateFormat as SDF

import com.ibm.icu.text.PluralFormat
import org.codehaus.groovy.grails.web.pages.GroovyPagesTemplateEngine
import org.codehaus.groovy.grails.plugins.web.taglib.JavascriptTagLib
import com.gramant.web.ui.Highlighter
import org.joda.time.format.DateTimeFormat
import org.joda.time.LocalDate
import org.codehaus.groovy.grails.web.servlet.mvc.GrailsWebRequest
import org.springframework.context.NoSuchMessageException
import org.springframework.context.MessageSourceResolvable
import org.springframework.context.support.DefaultMessageSourceResolvable

/**
 * Gramant common layout, CSS, page block management.
 */
public class CommonsTagLib {

    static returnObjectForTags = ['message']

    static final REQUIRES = [js: '__JSFILES', css: '__CSSFILES', gsp: '__GSPFILES']
    static final String IE7_ADDON_SUFFIX = "_ie7_addon";
    static final String RESOURCE_TRACKING_KEY = RequestBundle.class.name

    /** Groovy internals   */
    GroovyPagesTemplateEngine groovyPagesTemplateEngine

    /** Message source   */
    def messageSource

    /** Plugin manager */
    def pluginManager

    /** jQuery plugin config   */
    def jQueryConfig

    def getRequestBundle() {
        RequestBundle rb = request[RESOURCE_TRACKING_KEY]
        if (!rb) {
            rb = new RequestBundle(GrailsWebRequest.lookup(request))
            request[RESOURCE_TRACKING_KEY] = rb
        }
        rb
    }

    def requireOnce = { attrs ->
        def type = REQUIRES[attrs.type]
        def pluginType = REQUIRES[attrs.type] + "Plugin"
        def src = attrs.src

        if (!type) throw new IllegalArgumentException("Invalid [type] attribute for tag <g:requireOnce>!")
        if (!src) throw new IllegalArgumentException("[src] attribute must be specified to for <g:requireOnce>!")

        if (request."$type" == null) {
            request."$type" = [:]
            request."${type + IE7_ADDON_SUFFIX}" = [:]
            request."$pluginType" = [:]
        }
        if (request."$type"."${attrs.src}" == null) {
            request."$type"."${attrs.src}" = 1
            request."$pluginType"."${attrs.src}" = attrs.plugin
            if (attrs.ie7) {
                request."${type + IE7_ADDON_SUFFIX}"."${attrs.src}" = attrs.ie7;
            }
        } else {
            request."$type"."${attrs.src}"++
        }

    }

    def requireJSOnce = {attrs ->
        def src = attrs.src
        if (!src) throw new IllegalArgumentException("[src] attribute must be specified to for <g:requireJSOnce>!")
        requestBundle.registerJavascript(attrs.src, attrs.plugin, attrs.ie7 != null)
    }

    /**
     * attrs: ie7 - a name of an additional css for ie7 to be included .
     * The name of the additional css file can be any but according to the current convention it should be <attrs.src_without_ext>_ie7_addon.css .
     * Ex: treeSelector.css -> treeSelector_ie7_addon.css
     */
    def requireCSSOnce = {attrs ->
        def src = attrs.src
        if (!src) throw new IllegalArgumentException("[src] attribute must be specified to for <g:requireCSSOnce>!")
//        requireOnce(src: src, type: 'css', plugin: attrs.plugin, ie7: attrs.ie7)
        requestBundle.registerCSS(attrs.src, attrs.plugin, attrs.ie7 != null)
    }

    def requireGSPOnce = {attrs ->
        def src = attrs.src
        if (!src) throw new IllegalArgumentException("[src] attribute must be specified to for <g:requireGSPOnce>!")
        requireOnce(src: src, type: 'gsp', plugin: attrs.plugin)
    }

    /**
     * Load jQuery plugin, but only once per page.
     */
    def requirePlugin = { attrs ->
        if (!attrs.name) throw new IllegalArgumentException("[src] attribute must be specified to for <g:requireGSPOnce>!")
        if (attrs.name) {
            jQueryConfig.plugins."${attrs.name}".each {
                def name = it.toString()
                name = name.endsWith('.js') ? name[0..-4] : name
                requireJSOnce(src: 'jquery/' + name, plugin: attrs.plugin)
            }
        }
    }

    /**
     * Dump a javascript bundle file OR individual scripts depending on debug mode setting.
     * Generate a new bundle if available.
     */
    def javascriptBundle = { attrs ->
        requestBundle?.renderJavascripts(null)
        if (request[JavascriptTagLib.INCLUDED_JS]) {
//            out << '/*\n'
//            request[JavascriptTagLib.INCLUDED_JS].each { k ->
//                out << k
//                out << '\n'
//            }
//            out << '\n*/'
        }
    }

    /**
     * Dump a CSS bundle file OR individual files depending on debug mode setting.
     * Generate a new bundle if available.
     */
    def cssBundle = { attrs ->
        requestBundle?.renderCSS(null)
    }

    def allRequires = {attrs, body ->
        def type = REQUIRES[attrs.type]
        def pluginType = REQUIRES[attrs.type] + "Plugin"
      
        if (!type) throw new IllegalArgumentException("Invalid [type] attribute for tag <g:allRequires>!")

        if (request."$type" != null) {
            for (f in request."$type") {
                out << body([src: f.key, plugin: request."$pluginType".get(f.key)])
                String ie7Key = request."${type + IE7_ADDON_SUFFIX}".get(f.key);
                if (ie7Key) {
                    out << "\n<!--[if lte IE 7]>\n";
                    out << body([src: ie7Key, plugin: request."$pluginType".get(f.key)]) + "\n"
                    out << "<![endif]-->\n";

                }
            }
        }
    }

    def allJSRequires = {attrs, body ->
        out << allRequires(type: 'js', body)
        requestBundle?.renderJavascripts(attrs.v?attrs.v:null)
    }

    def allCSSRequires = {attrs, body ->
        out << allRequires(type: 'css', body)
        requestBundle?.renderCSS(attrs.v?attrs.v:null)
    }

    def allGSPRequires = {attrs, body ->
        out << allRequires(type: 'gsp', body)
    }

    /**
     * Plugin resources basedir.
     * HARDCODED!!!! fixme
     */
    def getBaseDir() {
        'plugins/' + getPluginName() + '-' + getPluginVersion()
    }

    def getPluginName() {
        'gramant-commons'
    }

    def getPluginVersion() {
        pluginManager.getGrailsPlugin(getPluginName()).version
    }

    /**
     * Include documented.css and shared JS parts.
     */
    def commonsHeader = {
        out << createCssForIE7Tags([dir: "css", file: "documented.css", plugin: pluginName]);
        // Does not work.
//        out << "\n<!--[if gte IE 7]>\n"
//        out << javascript(library: 'jquery.curvycorners.source', plugin: pluginName)
//        out << "<![endif]-->\n"
        out << javascript(library: 'commons', plugin: pluginName)
    }

    /**
     * Initialize datepicker.
     */
    def datepicker = {attrs ->
        def lang = attrs.language ?: (request.language ?: 'en')
        if (lang == 'ru') {
            out << javascript(library: 'ui.datepicker-ru', plugin: pluginName)
        }
        out << "<script type=\"text/javascript\">jQuery(document).ready(function(){setDatepickerDefaults('${lang}')});</script>"
    }

    /**
     * Render AJAX/static feedback window.
     */
    def feedback = {
        out << render(template: '/feedback/feedback', plugin: pluginName)
        out << render(template: '/feedback/dynamicFeedback', plugin: pluginName)
        out << '<div class="ajaxFeedbackContainer"></div>'
    }


    def treeSelector = { attrs, body ->
        def cssClass = attrs['class']
        def cssStyle = attrs['style']
        attrs.remove('class')
        attrs.remove('style')
        out << render(
            template: '/selector/treeSelector',
            model: [cssClass: cssClass, cssStyle: cssStyle, body: body, otherAttrs: attrs, pluginName: pluginName],
            plugin: pluginName
        )
    }

    def treeSelectorRenderer = { attrs, body ->
        def list = "<root>" + body() + "</root>"
        def xml = new XmlParser().parseText(list)
        xml.children().each {
            out << render(
                template: '/selector/treeSelectorCategory',
                model: [list: it, pluginName: pluginName],
                plugin: pluginName
            )
        }
    }

    def sqlHelper = {
        out << render(template: '/system/sqlHelper', plugin: pluginName)
    }

    /**
     * Truncates specified string if its length is more than the specified <code>maxChar</code>
     * value - string to truncate
     * maxChar - max length
     */
    def truncate = { attrs ->
        String value = attrs.value
        def maxChars = attrs.maxChars as int
        if (!value) {
            out << ''
            return
        }
        if (value.length() <= maxChars) {
            out << value
        } else {
            def truncated = value.substring(0, maxChars - 3)
            def lastSpace = truncated.lastIndexOf(" ")
            if (lastSpace > maxChars / 2) {
                out << value.substring(0, lastSpace) + "..."
            } else {
                out << truncated + "..."
            }
        }
    }

    /**
     * Displays number with label in the correct form. Number can have separate CSS class.
     */
    def smartNumber = { attrs ->
        if (attrs.value == null) { attrs.value = 0 }
        def code = attrs.remove('code')
        def locale = RCU.getLocale(request)
        def pattern = code ? messageSource.getMessage(code, null, locale) : attrs.remove('message')
        def value = attrs.remove('value') as int
        out << new PluralFormat(UL.forLocale(locale), pattern).format(value)
    }

    /** Displays truncated text with nice fade effect  */
    def textFade = { attrs ->
        def width = attrs.width ?  Integer.parseInt (attrs.width) - 16: 120;
        def terms = attrs.terms
        def text = attrs.text ?: ""
        out << "<div class='TextFade' title='${text.encodeAsHTML()}' style='width: ${width}px;'><span>"
        out << (terms ? Highlighter.highlight(text, terms, '<var>', '</var>') : text.encodeAsHTML())
        out << "</span></div>"
    }

    /**
     * Render message, also expanding any MessageSourceResolvable arguments.
     *
     * @attr error The error to resolve the message for. Used for built-in Grails messages.
     * @attr message The object to resolve the message for. Objects must implement org.springframework.context.MessageSourceResolvable.
     * @attr code The code to resolve the message for. Used for custom application messages.
     * @attr args A list of argument values to apply to the message, when code is used.
     * @attr default The default message to output if the error or code cannot be found in messages.properties.
     * @attr encodeAs The name of a codec to apply, i.e. HTML, JavaScript, URL etc
     * @attr locale override locale to use instead of the one detected
     */
    def message = { attrs ->
        messageImpl(attrs)
    }

    def messageImpl(attrs) {
        def messageSource = grailsAttributes.applicationContext.messageSource
        def locale = attrs.locale ?: RCU.getLocale(request)

        def text
        def error = attrs.error ?: attrs.message
        if (error) {
            if (error instanceof Map) {
                error = new DefaultMessageSourceResolvable([error.code] as String[], error.args ? expandLocalizableArgs(error.args, locale) as Object[] : null)
            }
            try {
                text = messageSource.getMessage(error, locale)
            } catch (NoSuchMessageException e) {
                if (error instanceof MessageSourceResolvable) {
                    text = error?.code
                } else {
                    text = error?.toString()
                }
            }
        } else if (attrs.code) {
            def code = attrs.code
            def args = attrs.args
            def defaultMessage
			if(attrs.containsKey('default')) {
				defaultMessage = attrs['default']
			} else {
				defaultMessage = code
			}

            def message = messageSource.getMessage(code, args == null ? null : expandLocalizableArgs(args, locale).toArray(),
                defaultMessage, locale)
            if (message != null) {
                text = message
            } else {
                text = defaultMessage
            }
        }
        if (text) {
            return attrs.encodeAs ? text."encodeAs${attrs.encodeAs}"() : text
        }
        ''
    }

    def expandLocalizableArgs(args, locale) {
        def messageSource = grailsAttributes.applicationContext.messageSource
        def result = []
        for(arg in (args as List)) {
            if (arg instanceof MessageSourceResolvable) {
                result << messageSource.getMessage((MessageSourceResolvable) arg, locale)
            } else if (arg instanceof Map) {
                result << messageSource.getMessage(arg.code, arg.args, locale)
            } else {
                result << arg
            }
        }
        result
    }

    /**
     * Render all non-field-specific errors.
     * Loops through each error and renders it as UL/LI list.
     */
    def renderGlobalErrors = { attrs, body ->
        def codec = attrs.codec ?: 'HTML'
        if (codec == 'none') codec = ''
        def renderAs = attrs.remove('as')
        if (!renderAs) renderAs = 'list'

        // Enforce JavaScript codec for JSON.
        if (renderAs == 'json') {
            codec = 'JavaScript'
        }

        def bean = attrs.remove('bean')
        def mc = GroovySystem.metaClassRegistry.getMetaClass(bean.getClass())
        def errors
        if (mc.hasProperty(bean, 'errors')) {
            errors = bean.errors
        }

        if (errors?.hasGlobalErrors()) {
            if (renderAs == 'list') {
                out << "<div class=\"message\"><ul>"
            } else if (renderAs == 'json') {
                out << '['
            }
            errors.getGlobalErrors().eachWithIndex { err, i ->
                if (i > 0 && renderAs == 'json') {
                    out << ','
                }
                switch (renderAs) {
                    case 'list':
                        out << "<li>${message(error: err, encodeAs: codec)}</li>"
                        break
                    case 'json':
                        out << "\'${message(error: err, encodeAs: codec)}\'"
                        break
                }
            }
            if (renderAs == 'list') {
                out << "</ul></div>"
            } else {
                out << ']'
            }
        } else if (renderAs == 'json') {
            out << []   // empty array
        }

    }

    /**
     * Render all field-specific errors.
     * Loops through each error and renders it as UL/LI list.
     */
    def renderFieldErrors = { attrs, body ->
        def codec = attrs.codec ?: 'HTML'
        if (codec == 'none') codec = ''

        def bean = attrs.remove('bean')
        def field = attrs.remove('field')
        def nowrap = attrs.remove('nowrap')
        def mc = GroovySystem.metaClassRegistry.getMetaClass(bean.getClass())
        def errors
        if (mc.hasProperty(bean, 'errors')) {
            errors = bean.errors
        }

        if (errors?.hasFieldErrors(field)) {
            if (!nowrap) {
                out << "<span class=\"InputErrors\">"
            }
            out << "<ul>"
            errors.getFieldErrors(field)?.each {
                out << "<li>${message(error: it, encodeAs: codec)}</li>"
            }
            out << "</ul>"
            if (!nowrap) {
                out << "</span>"
            }
        }

    }

    /**
     * See createCssForIE7Tags method
     * body: not used
     */
    def cssForIE7 = { attrs, body ->
        out << createCssForIE7Tags(attrs);
    }

    /**
     * Adds a css for IE7 to correct some problems of the browser. The css must be
     * vreated in the same catelog as original css and has a name
     * <original_name_without_ext>IE7_ADDON_SUFFIX.css
     * @param attrs - dir,<br>
     * file (original name without IE7_ADDON_SUFFIX but with css extension),<br>
     * plugin<br>
     * rev - svn(?) revision, used in some tags
     * @return string to out on page
     */
    private String createCssForIE7Tags(Map attrs) {
        StringBuilder sb = new StringBuilder();
        sb << "<link href=\"${resource(dir: attrs.dir, file: attrs.file, plugin: attrs.plugin)}${(attrs.rev)?('?rev=' + attrs.rev):''}\" media=\"screen\" rel=\"stylesheet\" type=\"text/css\">"
        if (attrs.file.length() >= 5) {
            String fileName = "${attrs.file.substring(0, attrs.file.length() - 4) + IE7_ADDON_SUFFIX}.css";
            sb << "\n<!--[if lte IE 7]>\n";
            sb << "<link href=\"${resource(dir: attrs.dir, file: fileName, plugin: attrs.plugin)}\" media=\"screen\" rel=\"stylesheet\" type=\"text/css\">\n";
            sb << "<![endif]-->\n";
        }
        return sb.toString();
    }

    /**
     * Format JODA objects as "DD.MM.YYYY HH:mm".
     */
    def formatDateTime = {attrs ->
        if (!attrs.value) { return }
        out << DateTimeFormat.forPattern("dd.MM.yyyy HH:mm").print(attrs.value);
    }

    /**
     * Format JODA objects as "1 July 2009".
     */
    def formatMonthYear = {attrs ->
        if (!attrs.value) { return }
        def dt = attrs.value instanceof LocalDate ? attrs.value.toDateTimeAtStartOfDay().toDate() : attrs.value.toDate()
        def myLocale = UL.forLocale(RCU.getLocale(request))
        out << new SDF("d MMMM yyyy", myLocale).format(dt).toLowerCase()
    }
}
