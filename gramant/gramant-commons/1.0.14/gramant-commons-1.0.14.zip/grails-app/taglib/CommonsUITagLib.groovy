/*
* CommonsUITagLib
*
* Copyright (c) 2011 Gramant. All Rights Reserved
*/

import org.springframework.web.servlet.support.RequestContextUtils as RCU

/**
 * jQuery UI common tags.
 */
public class CommonsUITagLib {

    /** Uses ui:xxxx namespace  */
    static namespace = 'ui'

    /** Message source */
    def messageSource

    /**
     * Column header sorting link.
     */
    def sortHeader = {attrs, body ->
        if (!attrs.sort) {
            throwTagError("Tag [sortHeader] is missing required attribute [sort]")
        }
        def linkParams = [:]
        linkParams.putAll(params)
        linkParams.remove("offset")
        if (params.sort && params.sort == attrs.sort) {
            linkParams.order = params.order == 'asc' ? 'desc' : 'asc'
        } else {
            linkParams.order = 'asc'
        }
        linkParams.sort = attrs.sort
        def action = attrs.action ?: actionName
        out << "<a href='${createLink(action: action, params: linkParams)}'"
        if (params.sort && params.sort == attrs.sort) {
            out << " class='sorted ${(params.order == 'desc' ? 'desc' : 'asc')}'"
        }
        out << ">"
        out << body() << "</a>"
    }


    /**
     * Same as standard "sortableColumn" but with parameter propagation.
     */
    def sortableColumn = {attrs, body ->
        out << "<th class=\"sortable\">${ui.sortHeader(action:attrs.action,sort:attrs.property){attrs.titleKey ? g.message(code:attrs.titleKey) : attrs.title?.encodeAsHTML()}}</th>"
    }

    /**
     * Display UI dialog.
     */
    def dialog = { attrs, body ->
        def id = attrs.id
        def title = attrs.title
        def clazz = attrs.class ? attrs.class : 'Alert'
        def showEffect = attrs.show
        def hideEffect = attrs.hide
        def width = attrs.width ? attrs.width : '420'
        def height = attrs.height
        def onOpen = attrs.onOpen
        def onClose = attrs.onClose        
        clazz = clazz[0..<1].toUpperCase() + clazz[1..<clazz.length()]
        if (!title) {
            def titleKey = attrs.titleKey
            if (titleKey) {
                title = messageSource.getMessage(titleKey, null, RCU.getLocale(request))
            }
        }
        out << '<div id="' + id + '" class="DialogContainer" style="display: none;"'
        if (title) {
            out << ' title="' + title.encodeAsHTML() + '"'
        }
        out << '>'
        out << body()
        out << '</div>'
        out << '<script type="text/javascript">'
        out << '$(document).ready(function() {'
        out << '$(\'#' + id + '\').dialog({'
        out << 'dialogClass: \'' + clazz + 'Window\', autoOpen: false, resizable: false, width: ' + width + ', minHeight: 0, '
        out << "open: function(event,ui) {$onOpen},"
        out << "close: function(event,ui) {$onClose},"        
        if (height) {
            out << 'height: ' + height + ', '
        }
        out << 'modal: true'
        if (showEffect) {
            out << ',show:\'' + showEffect + '\''
        }
        if (hideEffect) {
            out << ',hide:\'' + hideEffect + '\''
        }
        out << '});'
        out << '});'
        out << '</script>'
    }

    
    /**
     * Display UI dialog to confirm deletion.
     */
    def deleteDialog = { attrs, body ->
        def clazz = attrs.remove('class') as String
        if (!clazz) {
            clazz = 'Warning Alert'
        } else {
            if (!clazz.contains('Warning')) {
                clazz += ' Warning'
            }
            if (!clazz.contains('Alert')) {
                clazz += ' Alert'
            }
        }
        attrs.put('class', clazz)
        out << dialog(attrs, body)
    }

    /**
     * Quick search control for generic list.
     */
    def quickSearch = { attrs ->
        def id = attrs.remove('id')     // input element id
        def name = attrs.remove('name') ?: 'q'  // input element name
        def update = attrs.remove('update')     // table(list) element to be AJAX-updated
        def helperValue = attrs.remove('helperValue') ?: "${message(code:'quick.search')}"
        def onchange = attrs.remove('onchange') ?: '$(\'a.GroupAction\').addClass(\'Disabled\'); resizeAutoTables(); $(\'div.Main\').height($(\'div.MainContent\').position().top + $(\'div.MainContent\').outerHeight());'
        def action = attrs.remove('action') ?: 'search'
        def linkParams = [:]
        linkParams.putAll(params)
        linkParams.remove(name)
        linkParams.remove("offset")
        out << render(template:'/templates/qsearch',
            plugin:'gramant-commons',
            model:[id:id, helperValue:helperValue, update:update,name:name, onchange: onchange, action:action, linkParams: linkParams])
    }

    /**
     * Custom paginator.
     * Creates next/previous links to support pagination for the current controller
     *
     * <ui:paginate total="${Account.count()}" />
     */
    def paginate = {attrs ->
        def writer = out
        if (attrs.total == null)
            throwTagError("Tag [paginate] is missing required attribute [total]")

        def locale = RCU.getLocale(request)

        def total = attrs.total.toInteger()
        def action = (attrs.action ? attrs.action : (params.action ? params.action : "list"))
        def offset = params.offset?.toInteger()
        def max = params.max?.toInteger()
        def maxsteps = (attrs.maxsteps ? attrs.maxsteps.toInteger() : 10)

        if (!offset) offset = (attrs.offset ? attrs.offset.toInteger() : 0)
        if (!max) max = (attrs.max ? attrs.max.toInteger() : 10)

        def linkParams = [offset: offset - max, max: max]
        if (params.sort) linkParams.sort = params.sort
        if (params.order) linkParams.order = params.order
        if (attrs.params) linkParams.putAll(attrs.params)

        def linkTagAttrs = [action: action]
        if (attrs.controller) {
            linkTagAttrs.controller = attrs.controller
        }
        if (attrs.id != null) {
            linkTagAttrs.id = attrs.id
        }
        linkTagAttrs.params = linkParams

//        linkTagAttrs.update = attrs.container
//        linkTagAttrs.method = 'GET'

        if (total <= max) {
            // GC-33 output wrapping div anyway.
            writer << '<div class="paging"></div>'
            return
        }

        // determine paging variables
        def steps = maxsteps > 0
        int currentstep = (offset / max) + 1
        int firststep = 1
        int laststep = Math.round(Math.ceil(total / max))

        writer << '<div class="paging">'

		// display previous
	    if (currentstep > firststep) {
	        linkTagAttrs.class = 'prev page'
	        linkParams.offset = offset - max
	        writer << link(linkTagAttrs.clone()) {
	            (attrs.prev ? attrs.prev : messageSource.getMessage('paginate.prev', null, messageSource.getMessage('default.paginate.prev', null, 'Previous', locale), locale))
	        }
	    } else {
		    writer << '<span class="prev page">'
		    writer << messageSource.getMessage('paginate.prev', null, messageSource.getMessage('default.paginate.prev', null, 'Previous', locale), locale)
			writer << '</span>'
	    }

	    // display next
        if (currentstep < laststep) {
            linkTagAttrs.class = 'next page'
            linkParams.offset = offset + max
            writer << link(linkTagAttrs.clone()) {
                (attrs.next ? attrs.next : messageSource.getMessage('paginate.next', null, messageSource.getMessage('default.paginate.next', null, 'Next', locale), locale))
            }
        } else {
	        writer << '<span class="next page">'
		    writer << messageSource.getMessage('paginate.next', null, messageSource.getMessage('default.paginate.next', null, 'Next', locale), locale)
			writer << '</span>'
        }

        linkTagAttrs.class = ''

	    // display steps when steps are enabled
        writer << '<span class="pages">'
        writer << messageSource.getMessage('paginate.pages', null,
            messageSource.getMessage('default.paginate.pages', null, 'Pages', locale), locale) << ':&nbsp;'

	    writer << '<ul>'

        if (steps && laststep > firststep) {
            // determine begin and endstep paging variables
            int beginstep = currentstep - Math.round(maxsteps / 2) + (maxsteps % 2)
            int endstep = currentstep + Math.round(maxsteps / 2) - 1

            if (beginstep < firststep) {
                beginstep = firststep
                endstep = maxsteps
            }
            if (endstep > laststep) {
                beginstep = laststep - maxsteps + 1
                if (beginstep < firststep) {
                    beginstep = firststep
                }
                endstep = laststep
            }

            // display firststep link when beginstep is not firststep
            if (beginstep > firststep) {
                linkParams.offset = 0
                writer << link(linkTagAttrs.clone()) {firststep.toString()}
                writer << '<li>. . .</li>'
            }

            // display paginate steps
            (beginstep..endstep).each {i ->
                if (currentstep == i) {
                    writer << "<li class=\"current\"><a href=\"#\" onclick=\"return false;\">${i}</a></li>"
                }
                else {
	                linkTagAttrs.class = ''
                    linkParams.offset = (i - 1) * max
                    writer << '<li>' << link(linkTagAttrs.clone()) {i.toString()} << '</li>'
                }
            }

            // display laststep link when endstep is not laststep
            if (endstep < laststep) {
                writer << '<li>..</li>'
                linkParams.offset = (laststep - 1) * max
                writer << link(linkTagAttrs.clone()) { laststep.toString() }
            }
        }

        writer << '</ul></span></div>'

    }

    /** Selected for number of table rows to display on one page */
    def rowsPerPage = { attrs ->
        def value
        try {
            value = Integer.valueOf(params.max)
        } catch (Exception ex) {
            value = 10
        }
        def linkParams = [:]
        def options = attrs.options ?: [10, 50, 500]
        linkParams.putAll(params)
        linkParams.remove("q")
        linkParams.remove("offset")
        linkParams.remove("max")
        out << render(template: '/templates/rowsPerPage', plugin: 'gramant-commons', model: [value: value, action: attrs.action, linkParams: linkParams, options: options])
    }


    /**
     * This tag enables sort in an ascending/descending order on the particular attribute of an object, asynchronously.
     */
    def ajaxSortableColumn = {attrs ->
        def writer = out
        if (!attrs.property)
            throwTagError("Tag [remoteSortableColumn] is missing required attribute [property]")

        if (!attrs.title && !attrs.titleKey)
            throwTagError("Tag [remoteSortableColumn] is missing required attribute [title] or [titleKey]")

        if (!attrs.update)
            throwTagError("Tag [remoteSortableColumn] is missing required attribute [update]")

        if (!attrs.action)
            throwTagError("Tag [remoteSortableColumn] is missing required attribute [action]")

        def property = attrs.remove("property")
        def action = attrs.remove("action")
        def update = attrs.remove("update")

        def defaultOrder = attrs.remove("defaultOrder")
        if (defaultOrder != "desc") defaultOrder = "asc"

        // current sorting property and order
        def sort = params.sort
        def order = params.order

        // add sorting property and params to link params
        def linkParams = [:]
        if (params.id) linkParams.put("id", params.id)
        if (attrs.params) linkParams.putAll(attrs.remove("params"))
        linkParams.sort = property

        // determine and add sorting order for this column to link params
        attrs.class = (attrs.class ? "${attrs.class} sortable" : "sortable")
        if (property == sort) {
            attrs.class = attrs.class + " sorted " + order
            if (order == "asc") {
                linkParams.order = "desc"
            } else {
                linkParams.order = "asc"
            }
        } else {
            linkParams.order = defaultOrder
        }

        // determine column title
        def title = attrs.remove("title")
        def titleKey = attrs.remove("titleKey")
        if (titleKey) {
            if (!title) title = titleKey
            def messageSource = grailsAttributes.getApplicationContext().getBean("messageSource")
            def locale = RCU.getLocale(request)
            title = messageSource.getMessage(titleKey, null, title, locale)
        }

        writer << "<th "
        // process remaining attributes
        attrs.each {k, v ->
            writer << "${k}=\"${v.encodeAsHTML()}\" "
        }
        def after = "resizeAutoTables()"
        if (attrs.controller) {
            writer << """>${remoteLink(action: action, controller: attrs.controller, update: update, params: linkParams, onComplete: after) { title } }
                </th>"""
        } else {
        writer << """>${remoteLink(action: action, update: update, params: linkParams, onComplete: after) { title } }
                </th>"""
        }
    }

    /**
     * Enable period selection via 'from'-'to' datepickers
     */
    def periodSelector = { attrs ->
        out << render(template: '/selector/periodSelector', plugin: 'gramant-commons', model: [from: attrs.from, to: attrs.to, alwaysVisible: attrs.alwaysVisible, hideSelector: attrs.hideSelector])
    }

    /**
     * Load Javascript/CSS for the single-element autocompletion selector.
     */
    def selectOne = { attrs ->
        def id = attrs.id
        def cache = !(attrs.cache == 'false')
        def cssClass = attrs.'class'
        def cssStyle = attrs.'style'
        def embedNewFlag = attrs.embedNewFlag == null
        def name = attrs.name ?: id
        def paramName = attrs.paramName ?: attrs.name + '.id'
        def paramNameNew = attrs.paramNameNew
        def entity = attrs.entity
        def displayName = attrs.displayName != null ? attrs.displayName : entity?.'name'
        def value = attrs.value != null ? attrs.value : entity?.ident()
        def url = attrs.url
        def messagePrefix = attrs.messagePrefix
        def delay = attrs.delay
        def minLength = attrs.minLength
        def outsideSpinner = attrs.outsideSpinner == 'true' || attrs.outsideSpinner == 'yes'

        // We can decide New vs Old. by examining ident.
        def isNew = value && displayName

        requireAttribute 'id', id
        requireAttribute 'url', url
        requireAttribute 'messagePrefix', messagePrefix

        if (url instanceof Map) {
            url = g.createLink(url)
        }

        // Preload Javascript/CSS
        g.requireJSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/selector',plugin:'gramant-commons',ie7:true)

        out << render(
            template: '/selector/selectOne',
            plugin: 'gramant-commons',
            model: [id: id, name: name, url: url,
                    displayName: displayName,
                    paramName: paramName,
                    paramNameNew: paramNameNew,
                    value: value,
                    cache: cache,
                    cssClass:cssClass,
                    inputClass:attrs.inputClass,
                    inputStyle:attrs.inputStyle,
                    embedNewFlag:embedNewFlag,
                    messagePrefix: messagePrefix,
                    isNew: isNew,
                    delay: delay, minLength: minLength,
                    outsideSpinner: outsideSpinner,
                    allowRepeatSelect: attrs.allowRepeatSelect,
                    selection: attrs.selection,
                    cssStyle:cssStyle])

    }

    /**
     * Load Javascript/CSS for the multi-element autocompletion selector.
     */
    def selectMany = { attrs ->
        def id = attrs.id
        def cache = !(attrs.cache == 'false')
        def cssClass = attrs.'class'
        def cssStyle = attrs.'style'
        def paramName = attrs.paramName
        def paramNameNew = attrs.paramNameNew
        def selection = attrs.selection
        def url = attrs.url
        def messagePrefix = attrs.messagePrefix
        def overlay = attrs.overlay
        def outsideSpinner = attrs.outsideSpinner == 'true' || attrs.outsideSpinner == 'yes'
        def delay = attrs.delay
        def minLength = attrs.minLength
        def closeOnSelect = attrs.closeOnSelect

        requireAttribute 'id', id
        requireAttribute 'url', url
        requireAttribute 'paramName', paramName
        requireAttribute 'messagePrefix', messagePrefix

        if (url instanceof Map) {
            url = g.createLink(url)
        }

        // Preload Javascript/CSS
        g.requireJSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/selector',plugin:'gramant-commons',ie7:true)

        out << render(
            template: '/selector/selectMany',
            plugin: 'gramant-commons',
            model: [id: id, url: url, overlay: overlay,
                    items: attrs.items,
                    paramName: paramName,
                    paramNameNew: paramNameNew,
                    cache: cache,
                    cssClass: cssClass,
                    inputClass: attrs.inputClass,
                    messagePrefix: messagePrefix,
                    outsideSpinner: outsideSpinner,
                    delay: delay, minLength: minLength,
                    cssStyle:cssStyle, selection:selection, closeOnSelect: closeOnSelect])

    }

    def treeCombo = { attrs ->
        out << render(
            template: '/selector/treeCombo',
            plugin: 'gramant-commons',
            model: attrs)
    }


    def treeSelectMany = { attrs ->
        def id = attrs.id
        def cssClass = attrs.'class'
        def cssStyle = attrs.'style'
        def paramName = attrs.paramName
        def selection = attrs.selection
        def url = attrs.url
        def messagePrefix = attrs.messagePrefix
        def overlay = attrs.overlay
        def dynamicLoad = attrs.dynamicLoad ?: true
        def delay = attrs.delay
        def minLength = attrs.minLength
        def closeOnSelect = attrs.closeOnSelect
        def preloadRoot = attrs.preloadRoot ? attrs.preloadRoot == 'true' : true

        requireAttribute 'id', id
        requireAttribute 'url', url
        requireAttribute 'paramName', paramName
        requireAttribute 'messagePrefix', messagePrefix

        if (url instanceof Map) {
            url = g.createLink(url)
        }

        // Preload Javascript/CSS
        g.requireJSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireJSOnce(src:'views/treeSelectorNew',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/treeSelector',plugin:'gramant-commons')

        out << render(
            template: '/selector/treeSelectMany',
            plugin: 'gramant-commons',
            model: [id: id, url: url, overlay: overlay,
                    selection: attrs.selection,
                    paramName: paramName,
                    cssClass:cssClass,
                    inputClass:attrs.inputClass,
                    messagePrefix: messagePrefix,
                    dynamicLoad: dynamicLoad,
                    cssStyle:cssStyle, 
                    delay: delay, minLength: minLength,
                    outsideSpinner: attrs.outsideSpinner == 'true',
                    preloadRoot: preloadRoot,
                    closeOnSelect: closeOnSelect])
    }

    def treeSelectOne = { attrs ->
        def id = attrs.id
        def cssClass = attrs.'class'
        def cssStyle = attrs.'style'
        def paramName = attrs.paramName
        def url = attrs.url
        def messagePrefix = attrs.messagePrefix
        def overlay = attrs.overlay
        def dynamicLoad = attrs.dynamicLoad ?: true
        def preloadRoot = attrs.preloadRoot ? attrs.preloadRoot == 'true' : true

        requireAttribute 'id', id
        requireAttribute 'url', url
        requireAttribute 'paramName', paramName
        requireAttribute 'messagePrefix', messagePrefix

        if (url instanceof Map) {
            url = g.createLink(url)
        }

        // Preload Javascript/CSS
        g.requireJSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/selector',plugin:'gramant-commons')
        g.requireJSOnce(src:'views/treeSelectorNew',plugin:'gramant-commons')
        g.requireCSSOnce(src:'views/treeSelector',plugin:'gramant-commons')

        out << render(
            template: '/selector/treeSelectOne',
            plugin: 'gramant-commons',
            model: [id: id, url: url, overlay: overlay,
                    selection: attrs.selection,
                    paramName: paramName,
                    cssClass:cssClass,
                    inputClass:attrs.inputClass,
                    messagePrefix: messagePrefix,
                    dynamicLoad: dynamicLoad,
                    outsideSpinner: attrs.outsideSpinner == 'true',
                    preloadRoot: preloadRoot,
                    cssStyle:cssStyle])
    }

    def requireAttribute(attrName, attrValue) {
        if (!attrValue) {
            throw new IllegalArgumentException("Tag requires '${attrName}' attribute.")
        }

    }

}