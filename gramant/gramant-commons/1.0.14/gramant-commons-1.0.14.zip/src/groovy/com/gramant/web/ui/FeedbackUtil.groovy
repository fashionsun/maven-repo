/*
* FeedbackUtil
*
* Copyright (c) 2010 Gramant. All Rights Reserved
*/
package com.gramant.web.ui


import org.codehaus.groovy.grails.web.util.WebUtils
import org.springframework.web.servlet.support.RequestContextUtils as RCU
import com.ibm.icu.text.PluralFormat
import com.ibm.icu.util.ULocale as UL
import org.springframework.context.MessageSource
import java.text.MessageFormat

public class FeedbackUtil {

    /**
     * @param prefix resource bundle prefix
     * @param entities list of entities
     * @param extractor used for extracting entity names (only shown for single entity).
     * @return single or multi-entity localized message
     */
    private static String getBulkEntityFeedback(MessageSource messageSource, String prefix, List entities,
                                                Closure extractor, Locale locale, Object[] args) {
        if (entities.size() == 1) {
            def pattern = messageSource.getMessage(prefix, null, locale)
            def allArgs = []
            allArgs << extractor.call(entities[0])?.encodeAsHTML()
            if (args) {
                allArgs.addAll(args as List)
            }
            return new MessageFormat(pattern).format(allArgs as Object[])
        } else {
            def pattern = messageSource.getMessage(prefix + '.many', null, locale)
            // make a poor man's expansion of arguments
            // not really good if you want better args formatting..
            pattern = pattern.replaceAll(~/\{(\d+)\}/) { match, text ->
                int i = text as int
                return args[i].toString()
            }
            return new PluralFormat(UL.forLocale(locale), pattern).format(entities.size())
        }
    }

    /**
     * Add localized feedback message depending on how many entities
     * had been deleted.
     *
     * When failed to delete some entities, add a warning.
     * @param entities map of [String reason => List of entities], maps failure reason to list of failed entities.
     * A failure reason '' indicates success.
     */
    public static def addBulkChangeFeedback(Map entities, String codePrefix, Object... extraArguments) {
        def request = WebUtils.retrieveGrailsWebRequest()
        def flash = request.flashScope

        flash.message = getBulkChangeFeedback(entities, codePrefix, extraArguments)
    }


    /**
     * Used for returning feedback message rather than adding to flash scope.
     */  
    public static def getBulkChangeFeedback(Map entities, String codePrefix, Object... extraArguments) {
        getBulkChangeFeedbackWithCustomName(entities, codePrefix, {it.name}, extraArguments)
    }

    /**
     * Used for returning feedback message rather than adding to flash scope.
     * This method uses custom entity-name extraction closure, eg:
     * <code>getBulkChangeFeedbackWithCustomName(entities, codePrefix, {it.title}, extraArguments);</code>
     */
    public static def getBulkChangeFeedbackWithCustomName(Map entities, String codePrefix, Closure extractor, Object... extraArguments) {
        def request = WebUtils.retrieveGrailsWebRequest()
        MessageSource messageSource = request.attributes.messageSource
        def locale = RCU.getLocale(request.currentRequest)
        def mainMessage = getBulkEntityFeedback(messageSource, codePrefix, entities[''], extractor,
                locale, extraArguments)

        // add failures information, if present.
        for(e in entities) {
            if (e.key != '' && e.value) {
                // A failure can have its own plural formatting.
                mainMessage += '<br/>'
                mainMessage += getBulkEntityFeedback(messageSource, codePrefix + '.failed.' + e.key, e.value, extractor, locale, extraArguments)
            }
        }

        mainMessage
    }

}