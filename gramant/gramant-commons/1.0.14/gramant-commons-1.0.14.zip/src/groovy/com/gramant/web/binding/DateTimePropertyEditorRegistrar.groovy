/*
* DateTimePropertyEditorRegistrar
*
* Copyright (c) 2009 Gramant. All Rights Reserved
*/
package com.gramant.web.binding

import org.springframework.beans.PropertyEditorRegistry
import org.springframework.beans.PropertyEditorRegistrar
import org.joda.time.DateTime
import org.joda.time.LocalDate

/**
 * We don't use built-in date picker, so we need to register our own editor here.
 */
class DateTimePropertyEditorRegistrar implements PropertyEditorRegistrar {

    /**
     * Register data binding for DateTime fields using short date format.
     */
	void registerCustomEditors(PropertyEditorRegistry registry) {
        // here we need to override BAD editor specified by plugin.
        registry.registerCustomEditor(DateTime, new SimpleDateTimeEditor())
        registry.registerCustomEditor(LocalDate, new SimpleLocalDateEditor())
	}
}
