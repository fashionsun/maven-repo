/*
* MessageException
*
* Copyright (c) 2010 Gramant. All Rights Reserved
*/
package com.gramant

/**
 * Exception with localizable message
 */
class MessageException extends RuntimeException {

    /**
     * Error message arguments
     */
    private def messageArgs

    /**
     * Default constructor
     */
    public MessageException() {

    }

    /**
     * Constructs new exception with the specified message code
     * @param messageCode error message code
     */
    public MessageException(String messageCode) {
        super(messageCode)
    }

    /**
     * Constructs new exception with the specified message code and arguments
     * @param messageCode error message code
     * @param args message arguments
     */
    public MessageException(String messageCode, args) {
        super(messageCode)
        this.messageArgs = args
    }

    /**
     * Returns message arguments
     */
    def getMessageArguments() {
        return messageArgs
    }
}
