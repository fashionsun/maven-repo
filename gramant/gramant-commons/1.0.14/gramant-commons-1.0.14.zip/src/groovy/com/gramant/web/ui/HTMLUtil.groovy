/*
* FeedbackUtil
*
* Copyright (c) 2010 Gramant. All Rights Reserved
*/
package com.gramant.web.ui

import org.codehaus.groovy.grails.plugins.codecs.HTMLCodec

public class HTMLUtil {

    /**
     * Highlight term values in body using strong tag.
     */
    public static def highlight(text, term) {
        if (!term) {
            return text.encodeAsHTML()
        } else {
            return highlightTerm(text, term.split(), 'strong').join('')
        }
    }

    /**
     * Highlight term values in body using var tag.
     */
    public static def highlightVar(text, term) {
        if (!term) {
            return text?.encodeAsHTML()
        } else {
            return highlightTerm(text, term.split(), 'var').join('')
        }
    }

    /**
     * Highlights term if it is equal to text
     */
    public static def highlightVarFull(text, term) {
        if (text && term) {
            def lower = text.toLowerCase ()
            for (token in term.split()) {
                if (lower.equals (token.toLowerCase())) {
                    return "<var>" + text + "</var>"
                }
            }
        }
        return text
    }

    /**
     * Highlight terms in text with specified tag.
     */
    private static def highlightTerm(text, terms, tag) {
        def result = []
        if (text) {
            def lower = text.toLowerCase()
            def term = terms[0].toLowerCase()
            def currentIndex = 0
            def index = lower.indexOf(term)
            while (index >= 0) {
                if (index > currentIndex) {
                    result += terms.size() > 1 ? highlightTerm(text[currentIndex..(index - 1)], terms[1..-1], tag) : HTMLCodec.encode(text[currentIndex..(index - 1)])
                }
                result << "<" + tag + ">${HTMLCodec.encode(text[index..(index + term.size() - 1)])}</" + tag + ">"
                currentIndex = index + term.size()
                index = lower.indexOf(term, currentIndex)
            }

            if (currentIndex < text.size()) {
                result += terms.size() > 1 ? highlightTerm(text[currentIndex..-1], terms[1..-1], tag) : HTMLCodec.encode(text[currentIndex..-1])
            }
        }
        result
    }

    /** Exludes sorting and paging parameters from the specified map */
    public static def excludeLimits (params) {
        def result = [:]
        result.putAll (params)
        result.remove("sort")
        result.remove("order")
        result.remove("max")
        result.remove("offset")
        return result
    }
}