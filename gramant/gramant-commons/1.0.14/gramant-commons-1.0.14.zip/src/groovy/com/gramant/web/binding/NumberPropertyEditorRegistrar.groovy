/*
 * NumberPropertyEditorRegistrar.groovy
 * Copyright (c) 2011 Gramant
 */
package com.gramant.web.binding

import org.springframework.beans.PropertyEditorRegistrar
import org.springframework.beans.PropertyEditorRegistry

/**
 * Default Long editor uses DecimalFormat which is buggy. Thus registering replacement here.
 */
class NumberPropertyEditorRegistrar implements PropertyEditorRegistrar {
    void registerCustomEditors(PropertyEditorRegistry registry) {
        registry.registerCustomEditor(Long, new SimpleLongEditor())
        registry.registerCustomEditor(Integer, new SimpleIntegerEditor())
    }
}
