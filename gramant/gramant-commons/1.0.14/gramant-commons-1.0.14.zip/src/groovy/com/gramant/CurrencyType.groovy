/*
 * Currency
 *
 * Copyright (c) 2009 Gramant. All Rights Reserved
 */

package com.gramant

/**
 * Denotes a currencies list.
 *
 * @version ( VCS$Id : $ )
 */
public enum CurrencyType {

    RUB('RUB', 'руб.'),
    USD('USD', '$'),
    EUR('EUR', '€'),
    GBP('GBP', '£'),
    JPY('JPY', '¥')

    /** Currency id, currently it is code  */
    String id

    /** Currency sign  */
    String sign

    /**
     * Currency constructor.
     * @param id currency code
     * @param sign currency sign
     */
    CurrencyType(id, sign) {
        this.id = id
        this.sign = sign
    }


    /**
     * Currency code is the same as id.
     */
    public String getCode() {
        id
    }
}