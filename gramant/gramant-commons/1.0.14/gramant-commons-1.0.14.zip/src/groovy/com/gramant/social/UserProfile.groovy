/*
 * UserProfile
 *
 * Copyright (c) 2009 Gramant. All Rights Reserved
 */
package com.gramant.social

/**
 * User information from social network.
 */
public class UserProfile {

    /** Social UID of the user */
    String uid
    /** User's first name */
    String firstName
    /** User's last name */
    String lastName
    /** User's social nickname */
    String nickname
    /** Photo URL */
    String photo
    /** Current location */
//    Map currentLocation
    /** Hometown location */
//    Map hometownLocation
    /** Profile URL */
    String profileURL
    /** True if user information is unaccessable */
    boolean dummy
    /**
     * @return string representation
     */
    public String toString() {
        return "uid:${uid} firstName:${firstName} lastName:${lastName} nickname:${nickname} photo:${photo}".toString()
    }

    def getNiceName () {
        if (nickname) {
            return nickname
        }
        StringBuffer result = new StringBuffer ("")
        if (firstName) {
            result.append (firstName).append (" ")
        }
        if (lastName) {
            result.append (lastName)
        }
        return result.length() == 0 ? uid : result.toString()
    }
}