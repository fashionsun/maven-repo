@artifact.package@class @artifact.name@ {

    static transactional = true

    def serviceMethod() {

    }
}
