/*
 * ObjectPair
 *
 * Copyright (c) 2010 Gramant. All Rights Reserved
 */
package com.gramant;

/**
 * Pair of objects. Any of them could be null.
 */
public class ObjectPair {

    /** First and second object */
    private Object one, two;

    public ObjectPair(Object one, Object two) {
        this.one = one;
        this.two = two;
    }

    /**
     * The rule is that null equals null (!).
     * @param obj object to compare to
     * @return comparison result
     */
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof ObjectPair)) {
            return false;
        }
        ObjectPair o = (ObjectPair) obj;

        if (one == null) {
            if (o.one != null) {
                return false;
            }
            if (two == null) {
                return o.two == null;
            } else {
                return two.equals(o.two);
            }
        } else {
            if (!one.equals(o.one)) {
                return false;
            }
            if (two == null) {
                return o.two == null;
            } else {
                return two.equals(o.two);
            }
        }
    }

}
