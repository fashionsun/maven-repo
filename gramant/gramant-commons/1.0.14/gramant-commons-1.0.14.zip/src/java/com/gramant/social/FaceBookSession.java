package com.gramant.social;

import grails.converters.JSON;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.groovy.grails.web.converters.exceptions.ConverterException;
import org.codehaus.groovy.grails.web.json.JSONArray;
import org.codehaus.groovy.grails.web.json.JSONElement;
import org.codehaus.groovy.grails.web.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.SecureRandom;
import java.util.*;

/**
 * Encapsulates OAuth access to Graph and REST APIs.
 */
public class FaceBookSession {

    /**
     * Used for request logging.
     */
    private static final Logger REQUEST_LOG =  LoggerFactory.getLogger(FaceBook.class.getName() + ".dump");

    /** Access token */
    private String accessToken;

    /**
     * Response parser
     */
    private final FaceBookDeserializer parser = new FaceBookDeserializer();


    /**
     * Spawn Facebook session.
     * @param accessToken OAuth access token
     */
    public FaceBookSession(String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * Read personal data for the user.
     *
     * @param userId social user identifier
     * @return user's personal data
     */
    public UserProfile getPersonalData(String userId) {
        List<UserProfile> users = parser.parseUserData(apiCall("users.getInfo", "uids", userId, "fields", "first_name, last_name, pic_square, profile_url, current_location"));
        if (users != null && users.size() > 0) {
            return users.get(0);
        }
        return null;
    }

    /**
     * Read personal data for all friends of the user.
     *
     * @param userId social user identifier
     * @return friends personal data
     */
    public List<UserProfile> getFriends(String userId) {
        JSONElement json = apiCall("friends.get", "uid", userId);
        List<String> ids = new ArrayList<String>();
        for(Object el : (JSONArray) json) {
            ids.add(el.toString());
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            sb.append(ids.get(i));
            if (i < ids.size() - 1) {
                sb.append(",");
            }
        }

        return parser.parseUserData(
                apiCall("users.getInfo", "uids", sb.toString(),
                        "fields", "first_name,last_name,pic_square,current_location,profile_url"));
    }

    /**
     * Post a message on user friend wall
     *
     * @param sourceId message originator id
     * @param targetId message reciever id
     * @param message  message to post on reciever wall
     */
    public void postWall(String sourceId, String targetId, String message) {
        apiCall("facebook.stream.publish", "target_id", targetId, "uid", sourceId, "message", message);
    }

    /**
     * Create application widgets
     *
     * @param userId     page user id
     * @param profileBox boxes tab widget code
     * @param wallBox    wall widget code
     */
    public void createBox(String userId, String profileBox, String wallBox) {
        apiCall("facebook.profile.setFBML", "uid", userId, "profile", profileBox, "profile_main", wallBox);
    }


    /**
     * Make Rest API call and return response as string.
     *
     * @param method    method to be invoked
     * @param arguments invocation arguments
     * @return response XML
     * @throws ContainerException on any errors
     */
    public String apiRestCall(String method, String... arguments) throws ContainerException {
        HttpClient httpclient = new DefaultHttpClient();
        SecureRandom rnd = new SecureRandom();
        rnd.setSeed(System.currentTimeMillis());

        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("access_token", accessToken));
        params.add(new BasicNameValuePair("format", "json"));
        for (int i = 0; i < arguments.length / 2; i++) {
            params.add(new BasicNameValuePair(arguments[i * 2], arguments[i * 2 + 1]));
        }
        try {
            URI uri = URIUtils.createURI("https", "api.facebook.com", -1, "/method/" + method,
                        URLEncodedUtils.format(params, "UTF-8"), null);
            try {
                HttpGet httpGet = new HttpGet(uri);
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                String result = httpclient.execute(httpGet, responseHandler);
                REQUEST_LOG.debug(result);
                return result;
            } catch (IOException e) {
                throw new ContainerException("Unable to run " + uri, e);
            }
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Make Rest API call using JSON output.
     *
     * @param method    method to be invoked
     * @param arguments invocation arguments
     * @return response XML
     * @throws ContainerException on any errors
     */
    public JSONElement apiCall(String method, String... arguments) throws ContainerException {
        String response = null;
        try {
            response = apiRestCall(method, arguments);
            JSONElement json = JSON.parse(response);
            if (json instanceof JSONObject) {
                JSONObject obj = (JSONObject) json;
                if (obj.containsKey("error_code")) {
                    throw FaceBookError.recognize(obj.get("error_msg").toString(), Integer.parseInt(obj.get("error_code").toString()));
                }
            }
            return json;
        } catch (ConverterException e) {
            throw new MalformedResponseException(response, e);
        }
    }


    /**
     * Run many FQL queries at once
     * @param queries group of FQL queries.
     * @return query => results map
     */
    public Map<String, List> apiMultiquery(Map<String, String> queries) {
        JSONArray response = (JSONArray) apiCall("fql.multiquery", "queries", new JSON(queries).toString());
        Map<String, List> result = new HashMap<String, List>();
        for(int i = 0; i < response.size(); i++) {
            JSONObject q = response.getJSONObject(i);
            if (q.isNull("fql_result_set")) {
                result.put(q.getString("name"), Collections.EMPTY_LIST);
            } else if (q.get("fql_result_set") instanceof JSONObject && q.getJSONObject("fql_result_set").isEmpty()) {
                result.put(q.getString("name"), Collections.EMPTY_LIST);
            } else {
                result.put(q.getString("name"), q.getJSONArray("fql_result_set"));
            }
        }
        return result;
    }

}
