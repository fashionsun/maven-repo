/*
 * TimeRangeFormatter
 *
 * Copyright (c) 2009 Gramant. All Rights Reserved
 */
package com.gramant.web.ui;

import org.joda.time.ReadablePeriod;
import org.joda.time.Period;
import org.springframework.context.MessageSource;
import com.ibm.icu.text.PluralRules;
import com.ibm.icu.text.MessageFormat;
import com.ibm.icu.text.PluralFormat;
import com.ibm.icu.util.ULocale;

import java.util.Locale;

/**
 * Takes a plural format definition from resource bundle,
 * then formats a message according to number used.
 * <p>
 * Format is always retrieved using Spring's MessageSource.
 * Format always uses Russian numbering plural rules and <strong>must</strong> define three plurals:
 * <dl>
 * <dt>one</dt> <dd>"singular" form, represents N mod 10 == 1</dd>
 * <dt>few</dt> <dd>represents N mod 10 in 2..4</dd>
 * <dt>other</dt> <dd>all other plurals - represents N mod 10 in 0, 5..9 (this includes zero)</dd>
 * </dl>
 * <p>
 * See {@link com.ibm.icu.text.PluralFormat} javadocs for more details on formatting expressions.
 * After plural-based formatting, we apply ICU's {@link MessageFormat} to finally format the provided numeric value.
 * Example of plural format: <p/><code>my.plural.format=one{Odin stakan} few{{0} stakana} other{{0} stakanov}</code>
 * <p>
 * Time range formatting requires TWO formats to be defined:
 * <ol>
 * <li>Hours
 * <li>Minutes
 * </ol>
 *
 * @version (VCS$Id:$)
 */
public class TimeRangeFormatter {

    /** Resource key to lookup format pattern for hours */
    private String hoursMessageKey;
    /** Resource key to lookup format pattern for minutes */
    private String minutesMessageKey;

    /**
     * Create formatter object.
     * @param hoursMessageKey hours plural format
     * @param minutesMessageKey minutes plural format
     */
    public TimeRangeFormatter(String hoursMessageKey, String minutesMessageKey) {
        this.hoursMessageKey = hoursMessageKey;
        this.minutesMessageKey = minutesMessageKey;
    }

    /**
     * Main formatting method.
     * @param period period to be formatted
     * @param messageSource message source used for i18n
     * @param locale locale to be applied
     * @return formatted period (duration)
     */
    public String format(ReadablePeriod period, MessageSource messageSource, Locale locale) {
        ULocale loc = ULocale.forLocale(locale);
        PluralFormat hoursFormat = new PluralFormat(PluralRules.forLocale(loc),
                messageSource.getMessage(hoursMessageKey, null, locale));
        PluralFormat minutesFormat = new PluralFormat(PluralRules.forLocale(loc),
                messageSource.getMessage(minutesMessageKey, null, locale));
        Period range = period.toPeriod();
        String hours = new MessageFormat(hoursFormat.format(range.getHours())).format(new Object[] { range.getHours() });
        String minutes = new MessageFormat(minutesFormat.format(range.getMinutes())).format(new Object[] { range.getMinutes() });
        StringBuilder result = new StringBuilder();
        if (range.getHours() > 0) {
            result.append(hours);
            if (range.getMinutes() > 0) {
                result.append(' ').append(minutes);
            }
        } else {
            result.append(minutes);
        }
        return result.toString();
    }
}
