/*
 * AutoTimestamp
 *
 * Copyright (c) 2010 Gramant. All Rights Reserved
 */
package com.gramant.gorm;

import org.codehaus.groovy.transform.GroovyASTTransformationClass;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * TBD.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@GroovyASTTransformationClass("com.gramant.gorm.AutoTimestampingASTTransformation")
public @interface AutoTimestamp {
}
