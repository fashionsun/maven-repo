/*
* FaceBook
*
* Copyright (c) 2010 Gramant. All Rights Reserved
*/
package com.gramant.social;

import grails.converters.JSON;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.codehaus.groovy.grails.web.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.codehaus.groovy.grails.commons.ConfigurationHolder;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * FaceBook interaction using OAuth 2.0 and old REST API.
 */
public class FaceBook {

    /** Hashing algorithm used by OAuth 2.0 */
    private static String HASH_ALGO = "HMAC-SHA256";


    /**
     * Logger
     */
    private static final Logger LOG = LoggerFactory.getLogger(FaceBook.class);

    /**
     * Used for request logging.
     */
    private static final Logger REQUEST_LOG =  LoggerFactory.getLogger(FaceBook.class.getName() + ".dump");


    /**
     * Rest API endpoint address
     */
    private String restURL;

    /**
     * Graph/OAuth API endpoint.
     */
    private URI authURL;

    /**
     * Application id
     */
    private String applicationId;

    /**
     * Secure secret key.
     */
    private String applicationSecretKey;


    /**
     * Create facebook connector.
     * @param settings settings
     */
    public FaceBook(Map<String, Object> settings) {
        try {
            restURL = settings.get("facebook.restUrl").toString();
            authURL = new URI(settings.get("facebook.authUrl").toString());
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
        applicationId = settings.get("facebook.applicationId").toString();
        applicationSecretKey = settings.get("facebook.applicationSecretKey").toString();
    }


    /**
     * Create facebook connector using application-wide config.
     */
    @SuppressWarnings({"unchecked"})
    public FaceBook() {
        this((Map<String, Object>) ConfigurationHolder.getFlatConfig());
    }


    /**
     * Null-safe toString().
     * @param s object to be converted to string
     * @return null if s is null, otherwise s.toString()
     */
    private static String makeString(Object s) {
        return s != null ? s.toString() : null;
    }




    /**
     * Request the specified set of permissions.
     * @param callbackURL URL to redirect to when authorization is complete.
     * @param permissions set of permissions
     * @return Facebook authorization URL
     */
    public String authorize(String callbackURL, List<String> permissions) {
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        if (permissions != null && permissions.size() > 0) {
            params.add(new BasicNameValuePair("scope", StringUtils.collectionToDelimitedString(permissions, ",")));
        }
        params.add(new BasicNameValuePair("redirect_uri", callbackURL));
        params.add(new BasicNameValuePair("client_id", applicationId));
        try {
            return URIUtils.createURI(authURL.getScheme(), authURL.getHost(), authURL.getPort(), authURL.getPath() + "/authorize",
                        URLEncodedUtils.format(params, "UTF-8"), null).toString();
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Request OAuth token with the specified tracking code.
     * @param callbackURL URL to redirect to when authorization is complete.
     * @param code authorization code
     * @return access token
     */
    public String requestAuthToken(String callbackURL, String code) {
        List<NameValuePair> params = new ArrayList<NameValuePair>();
        params.add(new BasicNameValuePair("redirect_uri", callbackURL));
        params.add(new BasicNameValuePair("client_id", applicationId));
        params.add(new BasicNameValuePair("client_secret", applicationSecretKey));
        params.add(new BasicNameValuePair("code", code));
        try {
            HttpClient httpclient = new DefaultHttpClient();
            URI uri = URIUtils.createURI(authURL.getScheme(), authURL.getHost(), authURL.getPort(), authURL.getPath() + "/access_token",
                    URLEncodedUtils.format(params, "UTF-8"), null);
            REQUEST_LOG.info("requestAuthToken: {}", uri.toString());
            try {
                HttpGet httpGet = new HttpGet(uri);
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                String result = httpclient.execute(httpGet, responseHandler);
                List<NameValuePair> response = new ArrayList<NameValuePair>();
                URLEncodedUtils.parse(response, new Scanner(result), "UTF-8");
                String accessToken = null;
                for(NameValuePair pair : response) {
                    if (pair.getName().equals("access_token")) {
                        accessToken = pair.getValue();
                        break;
                    }
                }
                if (accessToken == null) {
                    throw new MalformedResponseException(result, "Facebook auth response: missing access token");
                }
                return accessToken;
            } catch (IOException e) {
                throw new ContainerException("Unable to run " + uri, e);
            } finally {
                // When HttpClient instance is no longer needed,
                // shut down the connection manager to ensure
                // immediate deallocation of all system resources
                httpclient.getConnectionManager().shutdown();
            }
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * Used to decode and verify data passed by Facebook using OAuth 2.0.
     * @param request signed request string, typically <code>params.signed_request</code>.
     * @return request data as a map
     */
    public Map<String, String> decodeSignedRequest(String request) {
        Base64 base64 = new Base64(true);
        try {
            byte[] signature = base64.decode(request.substring(0, request.indexOf('.')));
            String rawPayload = request.substring(request.indexOf('.') + 1);
            JSONObject payload = (JSONObject) JSON.parse(new String(base64.decode(rawPayload), "UTF-8"));
            if (!HASH_ALGO.equals(payload.getString("algorithm").toUpperCase())) {
                throw new ContainerException("Unknown hash algorithm: " + payload.getString("algorithm"));
            }
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(applicationSecretKey.getBytes("UTF-8"), mac.getAlgorithm()));
            byte[] result = mac.doFinal(rawPayload.getBytes("UTF-8"));

            if (!Arrays.equals(signature, result)) {
                throw new ContainerException("Request verification failed: bad signature.");
            }

            //noinspection unchecked
            return (Map<String, String>) payload;

        } catch (InvalidKeyException e) {
            throw new RuntimeException("Broken hash?", e);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Unable to find " + HASH_ALGO + " algorithm.", e);
        } catch (UnsupportedEncodingException e) {
            throw new ContainerException("UTF-8 not supported", e);
        }
    }


    /**
     * Typically used by Facebook Connect application.
     * Verifies that facebook user identity is available.
     * 
     * @param request servlet request
     * @return connection status: connected or not.
     */
    public boolean isConnected(HttpServletRequest request) {
        String fbData = null;
        if (request.getCookies() == null) {
            return false;
        }
        for(Cookie c : request.getCookies()) {
            if (c.getName().equals("fbs_" + applicationId)) {
                fbData = c.getValue();
                break;
            }
        }
        if (fbData == null || fbData.equals("")) {
            return false;
        }

        List<NameValuePair> params = new ArrayList<NameValuePair>();
        URLEncodedUtils.parse(params, new Scanner(fbData), "UTF-8");
        TreeMap<String, String> sortedParams = new TreeMap<String, String>();
        String signature = null;
        for (NameValuePair nvp : params) {
            if (nvp.getName().equals("sig")) {
                signature = nvp.getValue();
            } else {
                sortedParams.put(nvp.getName(), nvp.getValue());
            }
        }
        if (signature == null) {
            LOG.error("No Facebook signature, fbs cookie: {}", fbData);
            return false;
        }
        REQUEST_LOG.debug("Received Facebook data: {}", sortedParams);
        return sign(sortedParams).equals(signature);

    }


    /**
     * Typically used by Facebook Connect application.
     * If fbs_ cookie is available, verify it and extract
     * session info.
     *
     * @param request servlet request
     * @return user id or null
     */
    public String login(HttpServletRequest request) {
        String fbData = null;
        if (request.getCookies() == null) {
            return null;
        }
        for(Cookie c : request.getCookies()) {
            if (c.getName().equals("fbs_" + applicationId)) {
                fbData = c.getValue();
                break;
            }
        }
        if (fbData == null || fbData.equals("")) {
            return null;
        }

        List<NameValuePair> params = new ArrayList<NameValuePair>();
        URLEncodedUtils.parse(params, new Scanner(fbData), "UTF-8");
        TreeMap<String, String> sortedParams = new TreeMap<String, String>();
        String signature = null;
        for (NameValuePair nvp : params) {
            if (nvp.getName().equals("sig")) {
                signature = nvp.getValue();
            } else {
                sortedParams.put(nvp.getName(), nvp.getValue());
            }
        }
        if (signature == null) {
            LOG.error("No Facebook signature, fbs cookie: {}", fbData);
            return null;
        }
        REQUEST_LOG.debug("Received Facebook data: {}", sortedParams);
        if (sign(sortedParams).equals(signature)) {
            return sortedParams.get("uid");
        } else {
            return null;
        }

    }

    /**
     * Connect to Facebook by generating single sign-on cookie.
     * @param uid user id
     * @param response HTTP response
     */
    public void connect(String uid, HttpServletResponse response) {
        TreeMap<String, String> params = new TreeMap<String, String>();
        params.put("uid", uid);
        List<NameValuePair> cookie = new ArrayList<NameValuePair>();
        for(Map.Entry<String, String> entry : params.entrySet()) {
            cookie.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
        }
        cookie.add(new BasicNameValuePair("sig", sign(params)));
        Cookie c = new Cookie("fbs_" + applicationId, URLEncodedUtils.format(cookie, "UTF-8"));
        c.setPath("/");
        c.setMaxAge((int) TimeUnit.DAYS.toSeconds(365));
        response.addCookie(c);
    }

    /**
     * Make signature of name=value pairs.
     * @param params parameters to encode
     * @return MD5-signed string
     */
    protected String sign(SortedMap<String, String> params) {
        StringBuilder payload = new StringBuilder();
        for(Map.Entry entry : params.entrySet()) {
            payload.append(entry.getKey()).append('=').append(entry.getValue());
        }
        payload.append(applicationSecretKey);
        return sign(payload.toString());
    }

    /**
     * Make an MD5 digest of message.
     *
     * @param message message to be signed
     * @return digital signature
     */
    protected String sign(String message) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            return new String(Hex.encodeHex(md5.digest(message.getBytes("UTF-8"))));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Unable to initialize MD5 digest.");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 is not supported?");
        }
    }
}
