/*
 * SQLLogger
 *
 * Copyright (c) 2010 Gramant. All Rights Reserved
 */
package com.gramant.gorm;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

import java.util.*;

/**
 * Utility class for logging SQL statements and binding them to actual application code.
 */
public class SQLLoggingAppender extends AppenderSkeleton {

    /**
     * Log full stack trace
     */
    private boolean showFullStackTrace = true;


    /**
     * Constructs new appender
     */
    public SQLLoggingAppender () {
        if ("false".equals (System.getProperty("sql.debug.stacktrace"))) {
            showFullStackTrace = false;
        }
    }

    /**
     * @param trace trace element
     * @return do it look like a Grails class?
     */
    protected boolean isLookingLikeGrailsClass(StackTraceElement trace) {
        return trace.getFileName() != null && trace.getFileName().equals("BootStrap.groovy");
    }

    protected boolean isApplicationClass(StackTraceElement trace) {
        return trace.getClassName() != null && trace.getClassName().indexOf('.') == -1;
    }

    /**
     * Uses custom sanitization method, slightly modified Grails
     * sanitizer.
     *
     * @param trace stack trace to be analyzed
     * @return trace element index
     */
    protected int getApplicationClassEntry(StackTraceElement[] trace) {
        List<StackTraceElement> newTrace = new ArrayList<StackTraceElement>();
        StackTraceElement bestGuess = null;
        int bestIndex = 0, i = 0;
        for(StackTraceElement stackTraceElement : trace) {
            if (isLookingLikeGrailsClass(stackTraceElement)) {
                bestGuess = stackTraceElement;
                break;
            }
            if (bestGuess == null && isApplicationClass(stackTraceElement)) {
                bestGuess = stackTraceElement;
                bestIndex = i;
            }
            i++;
        }

        return bestGuess != null ? bestIndex : 1;

        // Only trim the trace if there was some application trace on the stack
        // if not we will just skip sanitizing and leave it as is
//        if (newTrace.size() > 0) {
//            // We don't want to lose anything, so log it
//            StackTraceElement[] clean = new StackTraceElement[newTrace.size()];
//            newTrace.toArray(clean);
////            t.setStackTrace(clean);
//        }
    }

    /**
     * Subclasses of <code>AppenderSkeleton</code> should implement this
     * method to perform actual logging. See also {@link #doAppend
     * AppenderSkeleton.doAppend} method.
     *
     * @since 0.9.0
     */
    @SuppressWarnings({"unchecked"})
    @Override
    protected void append(LoggingEvent event) {
        StackTraceElement[] trace = Thread.currentThread().getStackTrace();
        int stackIndex = getApplicationClassEntry(trace);
        StackTraceElement stackEntry = trace[stackIndex];
        RequestAttributes rattrs = RequestContextHolder.getRequestAttributes();
        if (rattrs != null) {

            if (rattrs instanceof ServletWebRequest) {
                if (((ServletWebRequest) rattrs).getHeader("X-Requested-With") != null) {
                    // Dump to console. AJAX request does not offer SQL logging.
                    System.err.println((stackEntry.getFileName() != null ? stackEntry.getFileName() : stackEntry.getClassName()) +
                            "." + stackEntry.getMethodName() + ":" + stackEntry.getLineNumber() +
                            "\n" + event.getMessage().toString());
                }
            }

            List<Map<String, Object>> log = (List<Map<String, Object>>)
                    rattrs.getAttribute("sqlLog", RequestAttributes.SCOPE_REQUEST);
            if (log == null) {
                log = new ArrayList<Map<String, Object>>();
                rattrs.setAttribute("sqlLog", log, RequestAttributes.SCOPE_REQUEST);
            }
            Map<String, Object> entry = new HashMap<String, Object>();
            entry.put("sql", event.getMessage().toString());
            entry.put("stackEntry", stackEntry);
            if (showFullStackTrace) {
                entry.put("stackTrace", trace);
            }
            log.add(entry);
        } else {
            System.err.println((stackEntry.getFileName() != null ? stackEntry.getFileName() : stackEntry.getClassName()) +
                    "." + stackEntry.getMethodName() + ":" + stackEntry.getLineNumber() +
                    "\n" + event.getMessage().toString());
        }
    }


    /**
     * Release any resources allocated within the appender such as file
     * handles, network connections, etc.
     * <p/>
     * <p>It is a programming error to append to a closed appender.
     *
     * @since 0.8.4
     */
    public void close() {
    }

    /**
     * This appender does not require a layout.
     * @return false
     * @since 0.8.4
     */
    public boolean requiresLayout() {
        return false;
    }
}
