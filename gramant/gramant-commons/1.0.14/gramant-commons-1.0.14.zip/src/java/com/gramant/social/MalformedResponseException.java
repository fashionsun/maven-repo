/*
 * MalformedResponseException
 *
 * Copyright (c) 2009 Gramant. All Rights Reserved
 */
package com.gramant.social;

/**
 * Indiciates invalid response received from social API server.
 */
public class MalformedResponseException extends ContainerException {

    /**
     * Create exception instance.
     * @param response response XML
     * @param message message explaining what's wrong
     * @since 1.4
     */
    public MalformedResponseException(String response, String message) {
        super(message + ":\n" + response);
    }

    /**
     * Create exception instance.
     * @param response response XML
     * @param cause the cause (which is saved for later retrieval by the
     *              {@link #getCause()} method).  (A <tt>null</tt> value is
     *              permitted, and indicates that the cause is nonexistent or
     *              unknown.)
     * @since 1.4
     */
    public MalformedResponseException(String response, Throwable cause) {
        super(response, cause);
    }
}
