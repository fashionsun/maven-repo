/*
 * SimpleIntegerEditor
 * Copyright (c) 2011 Gramant
 */
package com.gramant.web.binding;

import java.beans.PropertyEditorSupport;

public class SimpleIntegerEditor extends PropertyEditorSupport {

    public SimpleIntegerEditor() {
        super();
    }

    public String getAsText() {
        return getValue() != null ? getValue().toString() : null;
    }

    public void setAsText(String text) {
        if (text != null && text.length() > 0) {
            setValue(new Integer(text));
        } else {
            setValue(null);
        }
    }
}