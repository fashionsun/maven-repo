/*
 * VKontakteError
 *
 * Copyright (c) 2009 Gramant. All Rights Reserved
 */
package com.gramant.social;

/**
 * Facebook-specific error.
 */
public class FaceBookError extends ContainerException {

    /** OAuth token is invalid/expired */
    public static final int INVALID_OAUTH_TOKEN = 190;

    /** Facebook error code */
    private int errorCode;

    /**
     * @param message the detail message
     * @param errorCode internal Facebook error code
     */
    public FaceBookError(String message, int errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    /**
     * @return facebook numeric error code
     */
    public int getErrorCode() {
        return errorCode;
    }

    /**
     * Returns the detail message string of this throwable.
     *
     * @return the detail message string of this <tt>Throwable</tt> instance
     *         (which may be <tt>null</tt>).
     */
    @Override
    public String getMessage() {
        return super.getMessage() + " (error code [" + errorCode + "])";
    }

    /**
     * Recognize and throw general or specific FB exception.
     * @param message message from FB
     * @param errorCode error code from FB
     * @return exception object
     */
    public static FaceBookError recognize(String message, int errorCode) {
        FaceBookError e;
        switch (errorCode) {
            case INVALID_OAUTH_TOKEN:
                e = new FaceBookInvalidTokenException(message);
                break;
            default:
                e = new FaceBookError(message, errorCode);
                break;
        }
        return e;
    }
}
