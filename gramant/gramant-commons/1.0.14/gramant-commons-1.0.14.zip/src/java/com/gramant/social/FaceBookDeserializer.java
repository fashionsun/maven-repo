/*
* FaceBookDeserializer
*
* Copyright (c) 2009 Gramant. All Rights Reserved
*/
package com.gramant.social;

import org.codehaus.groovy.grails.web.json.JSONArray;
import org.codehaus.groovy.grails.web.json.JSONElement;
import org.codehaus.groovy.grails.web.json.JSONObject;
import java.util.List;
import java.util.ArrayList;

/**
 * FaceBook response parser.
 */
public class FaceBookDeserializer {

    /**
     * User info parser
     *
     * @param json json object
     * @return parsed list of UserProfile
     */
    public List<UserProfile> parseUserData(JSONElement json) {
        List<UserProfile> result = new ArrayList<UserProfile>();
        JSONArray users = (JSONArray) json;
        for(Object el : users) {
            JSONObject user = (JSONObject) el;
            UserProfile profile = new UserProfile();
            profile.setUid(user.get("uid").toString());
            profile.setFirstName(user.get("first_name").toString());
            profile.setLastName(user.get("last_name").toString());
            profile.setNickname(""); //no nicknames in FaceBook
            profile.setPhoto(user.get("pic_square").toString());
            profile.setProfileURL(user.get("profile_url").toString());
            result.add(profile);
        }
        return result;
    }

}
