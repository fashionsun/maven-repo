/*
 * LikeExpression
 */
package com.gramant.gorm;

import org.hibernate.criterion.MatchMode;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

/**
 * "like/ilike" expression with special character escaping.
 */
public class LikeExpression extends org.hibernate.criterion.LikeExpression {

    /**
     * Constructs expression with match mode = anywhere and ignoring case
     *
     * @param propertyName property name
     * @param value        match mode
     */
    public LikeExpression(String propertyName, String value) {
        this(propertyName, value, MatchMode.ANYWHERE, true);
    }

    /**
     * Constructor
     *
     * @param propertyName property name
     * @param value        search filter
     * @param matchMode    match mode
     * @param ignoreCase   true for 'ilike', false for 'like'
     */
    public LikeExpression(String propertyName, String value, MatchMode matchMode, boolean ignoreCase) {
        super(propertyName, escape(value, '!'), matchMode, '!', ignoreCase);
    }

    /**
     * Escapes special characters with !
     *
     * @param src string to escape
     * @param escapeChar escape character
     * @return escaped string
     */
    public static String escape(String src, char escapeChar) {
        final StringBuilder result = new StringBuilder();
        final StringCharacterIterator iterator = new StringCharacterIterator(src);
        char character = iterator.current();
        while (character != CharacterIterator.DONE) {
            switch (character) {
                case '_':
                case '%':
                case '!':
                case '\\':
                    result.append(escapeChar);
                default:
                    result.append(character);
                    break;
            }
            character = iterator.next();
        }
        return result.toString();
    }
}
