/*
 * CustomGrailsDomainConfiguration
 *
 * Copyright (c) 2008 Gramant. All Rights Reserved
 */
package com.gramant.gorm;

import org.codehaus.groovy.grails.commons.*;
import org.codehaus.groovy.grails.orm.hibernate.cfg.DefaultGrailsDomainConfiguration;
import org.hibernate.MappingException;
import org.hibernate.Hibernate;
import org.hibernate.engine.FilterDefinition;

import java.util.List;
import java.util.Map;
import java.util.Collections;

/**
 * Define space-based default filtering.
 */
public class CustomGrailsDomainConfiguration extends DefaultGrailsDomainConfiguration {

    /** Reference to Grails app */
    private GrailsApplication grailsApplication;
    /** Check lock status */
    private boolean configLocked;


    /**
     * Save an injected instance of GrailsApplication.
     * @param grailsApplication Grails app reference
     */
    public void setGrailsApplication(GrailsApplication grailsApplication) {
        super.setGrailsApplication(grailsApplication);
        this.grailsApplication = grailsApplication;
    }

    /**
     * Collect information about hibernate filters for domain objects.
     * @throws MappingException
     */
    @SuppressWarnings({"unchecked"})
    protected void secondPassCompile() throws MappingException {
        if (configLocked) {
            return;
        }

        super.secondPassCompile();

        // work around for HHH-2624
        // see http://jira.codehaus.org/browse/GRAILS-6807
        addFilterDefinition(new FilterDefinition("dynamicFilterEnabler","1=1", Collections.emptyMap()));
        
        // Add space filter definition
        addFilterDefinition(new FilterDefinition("spaceFilter", "SPACE_ID = :space_id",
                Collections.singletonMap("space_id", Hibernate.INTEGER)));

        // Find hibernateFilters static.
        GrailsClass[] domainClasses =
            this.grailsApplication.getArtefacts(DomainClassArtefactHandler.TYPE);
        for (GrailsClass c : domainClasses) {
            Object filters = c.getPropertyValue("hibernateFilters");
            if (filters != null) {
                if (filters instanceof List) {
                    List<String> hibernateFilters = (List<String>) filters;
                    for (String filterName : hibernateFilters) {
                        getClassMapping(c.getName()).addFilter(filterName, ((FilterDefinition)
                            getFilterDefinitions().get(filterName)).getDefaultFilterCondition());
                    }
                } else if (filters instanceof Map) {
                    Map<String, String> hibernateFilters = (Map<String, String>) filters;
                    for (String filterName : hibernateFilters.keySet()) {
                        String defaultFilterCondition = null;
                        if (hibernateFilters.get(filterName).equals("")) {
                            defaultFilterCondition = ((FilterDefinition) getFilterDefinitions().get(filterName)).getDefaultFilterCondition();
                        } else {
                            defaultFilterCondition = hibernateFilters.get(filterName);
                        }
                        getClassMapping(c.getName()).addFilter(filterName, defaultFilterCondition);
                    }
                }
            }

        }

        this.configLocked = true;
    }
}
