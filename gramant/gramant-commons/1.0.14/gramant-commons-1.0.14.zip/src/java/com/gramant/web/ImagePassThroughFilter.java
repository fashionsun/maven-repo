/*
 * ImagePassThroughFilter
 *
 * Copyright (c) 2010 Gramant. All Rights Reserved
 */
package com.gramant.web;

import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;

/**
 * Allows commons-images to be referenced by <code>/images/myImage.jpg</code>,
 * also checking if "local" application image is available.
 */
public class ImagePassThroughFilter extends OncePerRequestFilter {

    /** Alternative images base URL, eg. plugins/gramant-commons-0.1/images */
    private String baseURL;

    /**
     * Set alternative images base URL.
     * @param baseURL base images URL
     */
    public void setBaseURL(String baseURL) {
        this.baseURL = baseURL;
    }

    /**
     * If image does not exist, forward to plugin-specific resource.
     * Make sure that it doesn't happen twice.
     * @param request servlet request
     * @param response servlet response
     * @param filterChain filter chain
     * @throws IOException on I/O errors
     * @throws ServletException on servlet engine errors
     */
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        if (request.getServletPath().startsWith(baseURL)) {
            filterChain.doFilter(request, response);
            return;
        }
        String realPath = getServletContext().getRealPath(request.getServletPath());
        if (!new File(realPath).exists()) {
            RequestDispatcher dispatcher = request.getRequestDispatcher(baseURL + request.getServletPath());
            dispatcher.forward(request, response);
        } else {
            filterChain.doFilter(request, response);
        }
    }

}
