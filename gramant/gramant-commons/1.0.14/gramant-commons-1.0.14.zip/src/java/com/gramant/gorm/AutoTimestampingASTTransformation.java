/*
 * AutoTimestampingASTTransformation
 *
 * Copyright (c) 2008 Gramant. All Rights Reserved
 */
package com.gramant.gorm;

import org.codehaus.groovy.ast.ASTNode;
import org.codehaus.groovy.ast.ClassNode;
import org.codehaus.groovy.control.CompilePhase;
import org.codehaus.groovy.control.SourceUnit;
import org.codehaus.groovy.grails.commons.GrailsDomainClassProperty;
import org.codehaus.groovy.grails.compiler.injection.GrailsASTUtils;
import org.codehaus.groovy.transform.ASTTransformation;
import org.codehaus.groovy.transform.GroovyASTTransformation;
import org.joda.time.DateTime;

import java.lang.reflect.Modifier;

/**
 * An AST transformation that injects autotimestamping fields into domain class.
 */
@GroovyASTTransformation(phase = CompilePhase.CANONICALIZATION)
public class AutoTimestampingASTTransformation implements ASTTransformation {

    /**
     * Visit annotated node.
     * @param astNodes list of nodes
     * @param sourceUnit source
     */
    public void visit(ASTNode[] astNodes, SourceUnit sourceUnit) {
        for (ASTNode astNode : astNodes) {
            if (astNode instanceof ClassNode) {
                ClassNode cNode = (ClassNode) astNode;
                String cName = cNode.getName();
                if (cNode.isInterface()) {
                    throw new RuntimeException("Error processing interface '" + cName + ": not allowed for interfaces.");
                }

                ClassNode cParent = GrailsASTUtils.getFurthestParent(cNode);
                cParent.addProperty(GrailsDomainClassProperty.DATE_CREATED, Modifier.PUBLIC, new ClassNode(DateTime.class), null, null, null);
                cParent.addProperty(GrailsDomainClassProperty.LAST_UPDATED, Modifier.PUBLIC, new ClassNode(DateTime.class), null, null, null);

                // Right after these properties are added,
                // they will be auto-populated by Grails interceptors.
            }
        }
    }
}
