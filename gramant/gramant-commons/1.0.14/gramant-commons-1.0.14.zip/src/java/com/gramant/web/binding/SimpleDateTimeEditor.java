/*
 * SimpleDateTimeEditor
 *
 * Copyright (c) 2008 Gramant. All Rights Reserved
 */
package com.gramant.web.binding;

import org.joda.time.ReadableInstant;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.DateTimeFormat;

import java.beans.PropertyEditorSupport;

/**
 * Joda DateTime editor. Can be optionally customized with DateTimeFormatter.
 */
public class SimpleDateTimeEditor extends PropertyEditorSupport {

    public SimpleDateTimeEditor() {
        super();
    }

    public String getAsText() {
        return getFormatter().print((ReadableInstant) getValue());
    }

    public void setAsText(String text) {
        Object val;
        if (text == null || text.equals("")) {
            setValue(null);
            return;
        }
        try {
            val = getFormatter().parseDateTime(text);
        } catch (IllegalArgumentException ex) {
            //alternative formatter
            val = DateTimeFormat.forPattern("dd.MM.yyyy").parseDateTime(text);
        }
        setValue(val);
    }

	protected DateTimeFormatter getFormatter() {
        return DateTimeFormat.forPattern("dd.MM.yyyy HH:mm");
    }
}