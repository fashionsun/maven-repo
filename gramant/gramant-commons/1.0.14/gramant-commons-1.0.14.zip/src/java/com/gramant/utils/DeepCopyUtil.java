/*
 * DeepCopyUtil.java
 * Copyright (c) 2011 Gramant
 */

package com.gramant.utils;

import org.codehaus.groovy.grails.commons.DomainClassArtefactHandler;
import org.codehaus.groovy.grails.commons.GrailsApplication;
import org.codehaus.groovy.grails.commons.GrailsDomainClass;
import org.codehaus.groovy.grails.commons.GrailsDomainClassProperty;
import org.codehaus.groovy.runtime.DefaultGroovyMethods;
import org.codehaus.groovy.runtime.InvokerHelper;
import org.springframework.util.Assert;

import java.util.*;

/**
 * Helper class for making deep copy of domain objects.
 */
public class DeepCopyUtil {

    public static <T> T copyAll(GrailsApplication grailsApplication, T source, String... excluding) {
        Assert.notNull(source);
        @SuppressWarnings({"unchecked"})
        Class<T> clazz = (Class<T>) source.getClass();
        GrailsDomainClass domainClass = (GrailsDomainClass) grailsApplication.getArtefact(DomainClassArtefactHandler.TYPE, clazz.getName());
        Set<String> excludes = excluding == null ? null : new HashSet<String>(Arrays.asList(excluding));
        Map<String, Object> properties = new HashMap<String, Object>();
        for(GrailsDomainClassProperty prop : domainClass.getPersistentProperties()) {
            if (prop.getName().equals("dateCreated") || prop.getName().equals("lastUpdated") || prop.isIdentity()) {
                // ignore timestamps.
                continue;
            }
            if (prop.isAssociation() && !prop.isOwningSide()) {     // "dependent" side association - do not copy.
                // parent/children props - ignore...
            } else {
                if ((excludes == null || !excludes.contains(prop.getName()))) {
                    properties.put(prop.getName(), InvokerHelper.getProperty(source, prop.getName()));
                }
            }
        }
        return DefaultGroovyMethods.newInstance(clazz, new Object[] { properties });
    }
}
