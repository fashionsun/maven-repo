/*
 * Translit
 */
package com.gramant.utils;

import java.util.Map;
import java.util.TreeMap;

/**
 * Russian-English transliteration utility.
 */
public class Translit {

    /**
     * If any cyrillic characters found, make English transliteration. Otherwise
     * assume it is Latin and make Russian transliteration.
     * @param term term to be transliterated
     * @return all variants of transliteration
     */
    public static String[] allTransliterations(String term) {
        boolean cyrillic = false;
        for(int i = 0; i < term.length(); i++) {
            char c = Character.toLowerCase(term.charAt(i));
            if (c >= '\u0430' && c <= '\u044F') {
                cyrillic = true;
                break;
            }
        }
        term = term.trim();
        return cyrillic ? allEnglishTransliterations(term) : allRussianTransliterations(term);
    }


    /**
     * Make SOME transliterations for a Russian term.
     * @param term Russian term
     * @return transliterated variants
     */
    public static String[] allEnglishTransliterations(String term) {
        return allEnglishTransliterations(term, true);
    }

    /**
     * Make SOME transliterations for a Russian term.
     * @param term Russian term
     * @param skipUnknownSymbols true if unknown characters should be skipped, false otherwise
     * @return transliterated variants
     */
    public static String[] allEnglishTransliterations(String term, boolean skipUnknownSymbols) {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < term.length(); i++) {
            Character c = Character.toLowerCase(term.charAt(i));
            String[] literals = TRANSLIT_TABLE.get(c);
            if (literals != null) {
                sb.append(literals[0]);
            } else if (!skipUnknownSymbols) {
                sb.append (c);
            }
        }
        return (sb.length() > 0) ? new String[]{sb.toString()} : new String[0];
    }


    /**
     * Make SOME transliterations for an English term.
     * @param term English term
     * @return transliterated variants
     */
    public static String[] allRussianTransliterations(String term) {
        StringBuilder sb = new StringBuilder();
        int pos = 0;
        while (pos < term.length()) {
            boolean found = false;
            for(int len = 4; len >= 1; len--) {
                if (pos + len <= term.length()) {
                    String prefix = term.substring(pos, pos + len).toLowerCase();
                    Character[] chars = BACKLIT_TABLE.get(prefix);
                    if (chars != null && chars.length > 0) {
                        sb.append(chars[0]);
                        pos = pos + len;
                        found = true;
                        break;
                    }
                }
            }
            if (!found) {
                pos = pos + 1;
            }
        }
        return (sb.length() > 0) ? new String[]{sb.toString()} : new String[0];
    }


    private static final Map<Character, String[]> TRANSLIT_TABLE = new TreeMap<Character, String[]>();
    private static final Map<String, Character[]> BACKLIT_TABLE = new TreeMap<String, Character[]>();


    private static void rule(char c, String... variants) {
        TRANSLIT_TABLE.put(c, variants);
        for(String variant : variants) {
            Character[] currentOptions = BACKLIT_TABLE.get(variant);
            Character[] newOptions;
            if (currentOptions != null) {
                newOptions = new Character[currentOptions.length + 1];
                System.arraycopy(currentOptions, 0, newOptions, 0, currentOptions.length);
                newOptions[currentOptions.length] = c;
            } else {
                newOptions = new Character[] { c };
            }
            BACKLIT_TABLE.put(variant, newOptions);
        }
    }

    static {
        rule('а', "a");
        rule('б', "b");
        rule('в', "v", "8");
        rule('г', "g");
        rule('д', "d");
        rule('е', "e");
        rule('ё', "yo", "jo", "ö");
        rule('ж', "zh");
        rule('з', "z", "3");
        rule('и', "i");
        rule('й', "j", "jj");
        rule('к', "k");
        rule('л', "l");
        rule('м', "m");
        rule('н', "n");
        rule('о', "o");
        rule('п', "p");
        rule('р', "r");
        rule('с', "s");
        rule('т', "t");
        rule('у', "u");
        rule('ф', "f");
        rule('х', "kh", "h", "x");
        rule('ц', "c", "ts");
        rule('ч', "ch", "4");
        rule('ш', "sh");
        rule('щ', "shch", "w", "shh");
        //rule('ъ', "");
        rule('ы', "y");
        rule('ь', "'");
        rule('э', "e", "je", "ä", "eh");
        rule('ю', "yu", "ju", "ü");
        rule('я', "ya", "ja", "q");
    }
}
