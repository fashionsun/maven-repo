/*
* RingBufferAppender
*
* Copyright (c) 2010 Gramant. All Rights Reserved
*/
package com.gramant.utils;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

/**
 */
public class ArrayBufferAppender extends AppenderSkeleton {

    /** Ring buffer size */
    private static final int BUFFER_SIZE = 200;

    /** Current instance */
    private static ArrayBufferAppender ME = new ArrayBufferAppender();

    /** Logging buffer */
    private Queue<LoggingEvent> buffer = new ConcurrentLinkedQueue<LoggingEvent>();

    /** Cleanup thread */
    private final Thread cleanupThread;

    /** Is thread stopping? */
    private volatile boolean stopping = false;

    /**
     * Hidden constructor.
     */
    private ArrayBufferAppender() {
        setName("arrayBuffer");
        cleanupThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (!stopping) {
                        cleanup();
                        wait(TimeUnit.SECONDS.toMillis(10));
                    }
                } catch (InterruptedException e) {
                    // interrupted.
                }
            }
        });
        cleanupThread.setName("LoggingBufferCleanupThread");
        cleanupThread.setDaemon(true);
        cleanupThread.start();
    }


    /**
     * @return singleton instance of buffered appender.
     */
    public static ArrayBufferAppender getInstance() {
        return ME;
    }

    /**
     * Saves event into the buffer.
     * @param loggingEvent incoming logging event
     */
    @Override
    protected void append(LoggingEvent loggingEvent) {
        buffer.add(loggingEvent);
    }

    
    /**
     * Only clears the logging buffer.
     */
    @Override
    public synchronized void close() {
        buffer.clear();
        closed = true;
        stopping = true;
    }
    

    /**
     * @return <code>false</code>
     */
    @Override
    public boolean requiresLayout() {
        return false;
    }


    /**
     * External cleanup method.
     */
    public synchronized void cleanup() {
        int sz = buffer.size();
        if (sz > BUFFER_SIZE) {
            for(int i = 0; i < sz - BUFFER_SIZE; i++) {
                if (stopping) {
                    break;
                }
                buffer.poll();
            }
        }
    }


    /**
     * Get snapshot of the logging buffer for viewing.
     * @param sinceTimestamp since what time? (-1 for all)
     * @return all known events since this timestamp.
     */
    public synchronized LoggingEvent[] getSnapshot(long sinceTimestamp) {
        List<LoggingEvent> list = new ArrayList<LoggingEvent>(BUFFER_SIZE);
        int i = 0;
        LoggingEvent[] events = buffer.toArray(new LoggingEvent[BUFFER_SIZE]);
        for(LoggingEvent e : events) {
            if (e == null) {
                break;
            }
            if (sinceTimestamp < 0 || e.getTimeStamp() > sinceTimestamp) {
                list.add(e);
            }
            i++;
            if (i > BUFFER_SIZE) {
                break;
            }
        }
        return (LoggingEvent[]) list.toArray(new LoggingEvent[]{});
    }
}
