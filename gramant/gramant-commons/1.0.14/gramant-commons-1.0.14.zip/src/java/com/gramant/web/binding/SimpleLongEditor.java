/*
 * SimpleLongEditor
 * Copyright (c) 2011 Gramant
 */
package com.gramant.web.binding;

import java.beans.PropertyEditorSupport;

public class SimpleLongEditor extends PropertyEditorSupport {

    public SimpleLongEditor() {
        super();
    }

    public String getAsText() {
        return getValue().toString();
    }

    public void setAsText(String text) {
        Object val;
        if (text != null && text.length() > 0) {
            try {
                val = new Long(text);
            } catch (NumberFormatException e) {
                // do nothing
                throw e;
            }
            setValue(val);
        }
    }
}