/*
 * SimpleDateTimeEditor
 *
 * Copyright (c) 2008 Gramant. All Rights Reserved
 */
package com.gramant.web.binding;

import org.joda.time.ReadablePartial;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.DateTimeFormat;

import java.beans.PropertyEditorSupport;

/**
 * Very simple editor for date-only values (LocalDate).
 */
public class SimpleLocalDateEditor extends PropertyEditorSupport {

    /**
     * Create editor instance.
     */
    public SimpleLocalDateEditor() {
        super();
    }


    /**
     * Format LocalDate value.
     * @return value formatted using standard pattern
     */
    public String getAsText() {
        return getFormatter().print((ReadablePartial) getValue());
    }


    /**
     * Attempts to parse text as LocalDate.
     * @param text text containing local date
     */
    public void setAsText(String text) {
        setValue(getFormatter().parseDateTime(text).toLocalDate());
    }


    /**
     * @return default formatting pattern
     */
	protected DateTimeFormatter getFormatter() {
        return DateTimeFormat.forPattern("dd.MM.yyyy");
    }
}