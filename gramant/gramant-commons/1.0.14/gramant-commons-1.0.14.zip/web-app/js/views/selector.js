/*
 * "Combo" selector widget.
 *
 * See
 * http://docs.jquery.com/UI/Autocomplete
 *
 * Depends:
 *	jquery.ui.core.js
 *	jquery.ui.widget.js
 *	jquery.ui.position.js
 */

/** Selector namespace */
var Selector = {};

Selector.cache = {};


(function($, undefined) {

// used to prevent race  conditions with remote data sources
var requestIndex = 0;

$.widget("ui.lookup", {
	options: {
		appendTo: "body",
		box: "dropbox",     // Widget to use for drop-down box.
        overlay: false,
        outsideSpinner: false,
		autoFocus: false,
        autoSelectFirst: true,
        autoSelectNew: true,
        suggestNew: true,
        cssClass: '',
        cssStyle: '',
        menuWidth: null,
        /** Allow firing "select" event for items which are already selected. */
        allowRepeatSelect: false,
        html: true,
		delay: 200,
        cache: true,
		minLength: 1,
        jsonList: 'suggestions',
        closeOnSelect: true,
		position: {
			my: "left top",
			at: "left bottom",
			collision: "none"
		},
        deferred: null,
		messages: {
		    newOption: 'New option:',
		    newFlag: 'New option',
		    list: 'List'
		},

		/**
		 * Parameterize AJAX request.
		 */
 		parameterize: function(ajaxSettings) {
 		},

        /** Currently selected items */
        currentSelection: function() {
            return this.selectedIds;
        },

        /** Make AJAX call using url provided in options object */
        source: function(request, response) {
            var self = this;
            var ajaxOptions = {
                context: self,
                url: this.options.url,
                dataType: "json",
                data: { term: request.term },
                success: function(data) {
                    response(data[self.options.jsonList], data.newSuggestion);
                    self.stopProgress();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (textStatus != 'abort' && textStatus != 'error') {
                        alert(errorThrown);
                    }
                    self.stopProgress();
                }
            };
            this.options.parameterize.apply(this, [ajaxOptions]);
            $.ajax(ajaxOptions);
        },


        /**
         * By default, render LI A element using item.label as inner content.
         * item.label is rendered as plain-text OR html, depending on options.
         */
        render: function(listElement, item, status) {
            var content = $("<a></a>");
            if (this.options.html) {
                content.html(item.label);
            } else {
                content.text(item.label);
            }
            return $("<li></li>")
                    .append(content)
                    .appendTo(listElement);
        },

        /**
         * Render new suggestion block.
         * @param newSuggestionElement block to be rendered.
         * @param item item data to be rendered, exactly as provided by server.
         */
        renderNew: function(newSuggestionElement, item) {
            if (this.options.html) {
                newSuggestionElement.find('.Detail').html(item.label);
            } else {
                newSuggestionElement.find('.Detail').text(item.label);
            }
        }
	},

	pending: 0,
    overlay: false,

	_create: function() {

		var self = this,
			doc = this.element[0].ownerDocument,
			suppressKeyPress;

        this.overlay = this.options.overlay || ($.browser.msie);// && parseInt($.browser.version) < 8);

        var inputElement = this.element
            .addClass('SelectorLookup')
            .wrap('<div class="Selector"></div>');

        this.rootElement = this.element.parent()
                .addClass(this.options.cssClass)
                .attr("style", this.options.cssStyle);
        if (!this.options.outsideSpinner) {
            this.rootElement.addClass('WidgetWithSpinner');
        }
        this.rootElement.append(
            $('<a class="ShowList local" href="#"></a>').append($('<span></span>').text(this.options.messages.list))
        );

        var theList = $('<div class="TheList"><ul></ul></div>')
            .appendTo(this.rootElement);
        this.newOption = $('<div class="NewOption"></div>')
            .html(this.options.messages.newOption + ': &laquo;<span class="Detail"></span>&raquo;')
            .appendTo(theList);

        // we have an array, need to convert it to associative array
        this._initSelection();

        // !!!!
        // Input is adjusted according to outer div size.
        // !!!!
        var contWidth = parseInt($(this.rootElement).outerWidth());
        // Workaround for percentage values, eg BS-195
        var rootWidth = $(this.rootElement).css('width');
        var widthPercent = /width:\s*\d+%/im;
        if (rootWidth && (widthPercent.test($(this.rootElement).attr("style")) || rootWidth.substring(rootWidth.length - 1) == '%')) {
            // set inner width to 100%
            contWidth = null;
            $(inputElement).css('width', '100%');
        } else {
            // override box-sizing
            $(inputElement).css('box-sizing', 'content-box');
            $(inputElement).css('-moz-box-sizing', 'content-box');
            $(inputElement).css('-webkit-box-sizing', 'content-box');
            // specify exact width here...
            $(inputElement).width(contWidth - parseInt($(inputElement).css('padding-left')) - parseInt($(inputElement).css('padding-right')));
        }

		inputElement
			.addClass( "ui-lookup-input" )
			.attr("autocomplete", "off" )
			// TODO verify these actually work as intended
			.attr({
				role: "textbox",
				"aria-autocomplete": "list",
				"aria-haspopup": "true"
			})
			.bind("keydown.lookup", function(event) {
				if ( self.options.disabled || inputElement.attr( "readonly" ) ) {
					return;
				}

				suppressKeyPress = false;
				var keyCode = $.ui.keyCode;
				switch( event.keyCode ) {
				case keyCode.PAGE_UP:
					self._move( "previousPage", event );
					break;
				case keyCode.PAGE_DOWN:
					self._move( "nextPage", event );
					break;
				case keyCode.UP:
					self._move( "previous", event );
					// prevent moving cursor to beginning of text field in some browsers
					event.preventDefault();
					break;
				case keyCode.DOWN:
					self._move( "next", event );
					// prevent moving cursor to end of text field in some browsers
					event.preventDefault();
					break;
				case keyCode.ENTER:
				case keyCode.NUMPAD_ENTER:
					// when menu is open and has focus
					if (self.menu.active) {
						// #6055 - Opera still allows the keypress to occur
						// which causes forms to submit
						suppressKeyPress = true;
						event.preventDefault();
					}
					//passthrough - ENTER and TAB both select the current element
				case keyCode.TAB:
					if ( !self.menu.active ) {
						return;
					}
					self.menu.select( event );
					break;
				case keyCode.ESCAPE:
					inputElement.val(self.term);
                    if (self.menu.active) {
                        // we don't want ESC to be propagated to dialogs.
                        suppressKeyPress = true;
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    self.close(event);
					break;
				default:
					// keypress is triggered before the input value is changed
					clearTimeout(self.searching);
					self.searching = setTimeout(function() {
						// only search if the value has changed
						if ( self.term != inputElement.val() ) {
							self.selectedItem = null;
							self.search( null, event );
						}
					}, self.options.delay );
					break;
				}
			})
			.bind( "keypress.lookup", function( event ) {
				if ( suppressKeyPress ) {
					suppressKeyPress = false;
					event.preventDefault();
				}
			})
			.bind("focus.lookup", function() {
				if (self.options.disabled) {
					return;
				}

				self.selectedItem = null;
				self.previous = inputElement.val();

                // if we are empty and helper not enabled, enable it.
                self.hideHelperText();
			})
			.bind("blur.lookup", function(event) {
				if (self.options.disabled) {
					return;
				}

				clearTimeout(self.searching);

				// clicks on the menu (or a button to trigger a search) will cause a blur event
				self.closing = setTimeout(function() {
                    self.showHelperText();
					self.close(event);
					self._change(event);
				}, 150);
			});
		this._initSource();
		this.response = function() {
			return self._response.apply(self, arguments);
		};
        var menuBox = theList.addClass("ui-lookup");
        if (this.overlay) {
            // Wrap menuBox with div.Selector to make CSS working correctly...
            menuBox.hide().wrap("<div class=\"Selector Open\" />").parent().appendTo($("body", doc)[0]);
        }
//			.appendTo( $( this.options.appendTo || "body", doc )[0] )
			// prevent the close-on-blur in case of a "slow" click on the menu (long mousedown)
        this.menu = menuBox
			.mousedown(function( event ) {
				// clicking on the scrollbar causes focus to shift to the body
				// but we can't detect a mouseup or a click immediately afterward
				// so we have to track the next mousedown and close the menu if
				// the user clicks somewhere outside of the autocomplete
				var menuElement = self.menu.element[ 0 ];
				if ( !$( event.target ).closest( ".ui-menu-item" ).length ) {
					setTimeout(function() {
						$( document ).one( 'mousedown', function( event ) {
							if ( event.target !== inputElement[0] &&
								event.target !== menuElement &&
								!$.ui.contains( menuElement, event.target ) ) {
								self.close();
							}
						});
					}, 1 );
				}

				// use another timeout to make sure the blur-event-handler on the input was already triggered
				setTimeout(function() {
					clearTimeout( self.closing );
				}, 13);
			})
			[this.options.box]({
				focus: function( event, ui ) {
					var item = ui.item.data("item.lookup");
					if (false !== self._trigger("focus", event, { item: item })) {
						// use value to match what will end up in the input, if it was a key event
						if ( /^key/.test(event.originalEvent.type) ) {
							inputElement.val(item.value);
						}
					}
				},
				selected: function( event, ui ) {
					var item = ui.item.data("item.lookup"),
						previous = self.previous;

                    var wasActive = self.menu.active;

					// only trigger when focus was lost (click on menu)
					if (inputElement[0] !== doc.activeElement) {
						inputElement.focus();
						self.previous = previous;
						// #6109 - IE triggers two focus events and the second
						// is asynchronous, so we need to reset the previous
						// term synchronously and asynchronously :-(
						setTimeout(function() {
							self.previous = previous;
							self.selectedItem = item;
						}, 1);
					}

                    // if already selected we can suppress this...
                    if (self.options.allowRepeatSelect || !(parseInt(item.id) in self.options.currentSelection.apply(self, []))) {
                        if (false !== self._trigger( "select", event, { item: item, isNew: ui.isNew })) {
                            inputElement.val(item.value);
                        }
                        // reset the term after the select event
                        // this allows custom select handling to work properly
                        self.term = inputElement.val();
                    }

                    if (self.options.closeOnSelect) {
					    self.close(event);
                    } else if (self.menu.active) {
                        // are we selected?
                        self.menu.active.addClass("Selected");
                    }
					self.selectedItem = item;
				},
				blur: function( event, ui ) {
					// don't set the value of the text field if it's already correct
					// this prevents moving the cursor unnecessarily
					if ( self.menu.element.is(":visible") &&
						( inputElement.val() !== self.term ) ) {
						inputElement.val( self.term );
					}
				}
			})
			.zIndex( this.element.zIndex() + 1 )
			// workaround for jQuery bug #5781 http://dev.jquery.com/ticket/5781
//			.css({ top: 0, left: 0 })
			.data(this.options.box);
		if ($.fn.bgiframe) {
			 this.menu.element.bgiframe();
		}

        if (this.options.outsideSpinner) {
            this.spinner = $('<div class="OutsideSpinner"></div>').prependTo(this.rootElement);
        }

        if (this.options.menuWidth) {
            this.menu.element.css('width', this.options.menuWidth);
        } else if (contWidth) {
            this.menu.element.width(contWidth);
        } else {
            this.menu.element.css('width', '100%');
        }

        if (!this.options.outsideSpinner) {
//            this.rootElement.find('.ShowList').css('right', '40px');
        }

        this.rootElement.find('.ShowList').click(function() {
            if ($(self.rootElement).hasClass('Open')) {
                self.close();
                inputElement.focus();
            } else {
                inputElement.focus();      // need to focus input field in order to get correct selection.
                self.listAll();
            }
            return false;
        });

        this.showHelperText();
	},

    hideHelperText: function() {
        if (this.element.val() == this.element.attr("helperValue") && this.element.hasClass("withHelperEnabled")) {
            this.element.removeClass("withHelperEnabled");
            this.element.val('');
        }
    },

    showHelperText: function() {
        if (this.element.val() == '' && !this.element.hasClass("withHelperEnabled")) {
            this.element.addClass("withHelperEnabled");
            this.element.val(this.element.attr("helperValue"));
        }
    },

    startProgress: function() {
        this.pending++;
        if (this.options.outsideSpinner) {
            $(this.spinner)
                    .zIndex(this.element.zIndex() + 1)
                    .show()
                    .position({my: "left", at: "right", collision: "none", of: this.element})
                    .addClass("WidgetLoading");

            $(this.spinner).position({my: "left top", at: "right top", of: this.element});
        } else {
            $(this.rootElement).addClass("WidgetLoading");
        }
    },

    stopProgress: function() {
        this.pending--;
        if (this.pending <= 0) {
            if (this.options.outsideSpinner) {
                $(this.spinner).removeClass("WidgetLoading");
            } else {
                $(this.rootElement).removeClass("WidgetLoading");
            }
        }
    },

	destroy: function() {
		this.element
			.removeClass("ui-lookup-input")
			.removeAttr("autocomplete")
			.removeAttr("role")
			.removeAttr("aria-autocomplete")
			.removeAttr("aria-haspopup")
            .unwrap();
        this.menu.element.remove();
		$.Widget.prototype.destroy.call(this);
	},

	_setOption: function( key, value ) {
		$.Widget.prototype._setOption.apply( this, arguments );
        // Cannot reset source this way...
        if (key == 'selectedIds') {
            this._initSelection();
        }
//		if ( key === "appendTo" ) {
//			this.menu.element.appendTo( $( value || "body", this.element[0].ownerDocument )[0] )
//		}
		if ( key === "disabled" && value && this.xhr ) {
			this.xhr.abort();
		}
	},

    /**
     * We only support remote JSON sources, so I removed any other cases.
     */
	_initSource: function() {
        var self = this;
        this.source = this.options.source;
    },

    _initSelection: function() {
        this.selectedIds = {};
        if (typeof(this.options.selectedIds) != "undefined") {
            for(var i = 0; i < this.options.selectedIds.length; i++) {
                this.selectedIds[parseInt(this.options.selectedIds[i])] = true;
            }
        }
    },


    listAll: function() {
        this.term = '';

        clearTimeout(this.closing);
        if (this._trigger("search", null) === false) {
            return;
        }

        return this._search('');
    },

	search: function(value, event) {
		value = value != null ? value : this.element.val();

		// always save the actual value, not the one passed as an argument
		this.term = this.element.val();

		if (value.length < this.options.minLength) {
			return this.close(event);
		}

		clearTimeout( this.closing );
		if ( this._trigger( "search", event ) === false ) {
			return;
		}

		return this._search(value);
	},

    _getCacheSuffix: function(term) {
        return term;
    },

    /**
     * Deferred-get of cached content.
     * @param term term to search for
     */
    _getDeferredResponse: function(term, loader) {
        var resp = this.options.cache ? this._getCachedResponse(term) : null;
        if (!resp) {
            resp = new $.Deferred();
            Selector.cache[this.options.url + ':' + this._getCacheSuffix(term)] = resp;
            loader(resp);
        }
        return resp;
    },

    _getCachedResponse: function(term) {
        return Selector.cache[this.options.url + ':' + this._getCacheSuffix(term)];
    },
    _setCachedResponse: function(term, response, extra) {
        Selector.cache[this.options.url + ':' + this._getCacheSuffix(term)] = [response, extra];
    },

	_search: function(value) {
        // Register for a pending response.
        var self = this;
        var term = value;
        this._getDeferredResponse(value, function(deferredObj) {
            self.startProgress();
            self.source.apply(self, [{term:value}, function(suggestions, newOption) { deferredObj.resolve([suggestions, newOption]); }]);
        }).done(function(result) {
            // Pass to the response processing code.
            if (self.term == value) {
                self._response.apply(self, result);
            }
        });
//        if (value == '' && this.options.cache && this._getCachedResponse(value)) {
//            this._response.apply(this, this._getCachedResponse(value));
////            this.pending++;
//        } else {
//            this.startProgress();
//
//            this.source.apply(this, [{term: value}, this.response]);
//        }
	},

	_response: function(content, newSuggestion) {
        // We can get no content, BUT a NEW suggestion.
		if (!this.options.disabled && ((content && content.length) || newSuggestion)) {
            if (this.term == '' && this.options.cache && !this._getCachedResponse('')) {
                this._setCachedResponse('', content);
            }
			this._suggest(content, newSuggestion);
			this._trigger("open");
		} else {
			this.close();
		}
	},

	close: function( event ) {
		clearTimeout(this.closing);
		if (this.menu.element.is(":visible")) {
            this.rootElement.removeClass('Open');
            if (this.overlay) {
                this.menu.element.hide();
            }
			this.menu.deactivate();
			this._trigger("close", event);
		}
	},

	_change: function(event) {
		if ( this.previous !== this.element.val() ) {
			this._trigger( "change", event, { item: this.selectedItem } );
		}
	},

	_normalize: function( items ) {
		// assume all items have the right format when the first item is complete
		if ( items.length && items[0].label && items[0].value ) {
			return items;
		}
		return $.map( items, function(item) {
			if ( typeof item === "string" ) {
				return {
					label: item,
					value: item
				};
			}
			return $.extend({
				label: item.label || item.value,
				value: item.value || item.label
			}, item );
		});
	},

	_suggest: function(items, newSuggestion) {
        this.menu.element.zIndex(this.rootElement.zIndex() + 1);
        var ul = this.menu.element.find('ul');
        this._renderMenu(ul, items, newSuggestion);
		// TODO refresh should check if the active item is still in the dom, removing the need for a manual deactivate
		this.menu.deactivate();
		this.menu.refresh();

		// size and position menu
        if (this.overlay) {
            this.menu.element.show();

            // For some reason _resizeMenu causes annoying blinking!
            this._resizeMenu();
    		this.menu.element.position($.extend({
    			of: this.element
    		}, this.options.position));
        }

        this.rootElement.addClass('Open');

        if (newSuggestion && this.options.autoSelectNew) {
            this.menu.activate(new $.Event("mouseover"), this.menu.newSuggestion);
        } else if ((items || newSuggestion) && this.options.autoSelectFirst) {
            this._move('next', new $.Event("mouseover"));
        }
	},

    _overrideHeight: function() {
        // For IE7 set max height.
        var ul = this.menu.element;
        $('#tester').text(ul.height() + '|' + ul.parent().height())
        if ($.browser.msie && parseInt($.browser.version) < 8 && ul.height() > 200) {
//            $('#tester').text('resize')
            ul.css('height', '200px');
        }
    },

	_resizeMenu: function() {
		var ul = this.menu.element;
		ul.outerWidth(Math.max(
			ul.width("").outerWidth(),
			this.element.outerWidth()
		));
        this._overrideHeight();
	},

	_renderMenu: function(ul, items, newSuggestion) {
		var self = this;
		ul.empty();
        var currentSelection = this.options.currentSelection.apply(this, []);
		$.each(items, function(index, item) {
            var status = {index:index};
            if (index == 0) {
                status.first = true;
            }
            if (index == (items.length - 1)) {
                status.last = true;
            }
			var ii = self.options.render.apply(self, [ul, item, status]);
            if (currentSelection && parseInt(item.id) in currentSelection) {
                ii.addClass("Selected");
            }
            ii.data("item.lookup", item);
		});
        if (items.length == 0) {
            this.menu.element.addClass('EmptyList');
        } else {
            this.menu.element.removeClass('EmptyList');
        }
        if (newSuggestion) {
            this.rootElement.addClass('WithNewOption');
            if (this.overlay) {
                this.menu.element.parent().addClass("WithNewOption");
            }
            this.options.renderNew.apply(this, [this.newOption, newSuggestion]);
            this.newOption.data("item.lookup", newSuggestion);
        } else {
            this.rootElement.removeClass('WithNewOption');
            if (this.overlay) {
                this.menu.element.parent().removeClass("WithNewOption");
            }
            this.newOption.removeData("item.lookup");
        }
	},

	_move: function(direction, event) {
		if (!this.menu.element.is(":visible")) {
			this.search(null, event);
			return;
		}
        if (this.menu.first() && /^previous/.test(direction)) {
            if (this.menu.beforeFirst(event)) {
                this.element.val(this.term);
                this.menu.deactivate();
            }
            return;
        }
		if (this.menu.last() && /^next/.test(direction)) {
            if (this.menu.afterLast(event)) {
                this.element.val(this.term);
                this.menu.deactivate();
            }
			return;
		}
		this.menu[ direction ]( event );
	}
});

$.extend($.ui.lookup, {
	escapeRegex: function( value ) {
		return value.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
	},
	filter: function(array, term) {
		var matcher = new RegExp( $.ui.lookup.escapeRegex(term), "i" );
		return $.grep( array, function(value) {
			return matcher.test( value.label || value.value || value );
		});
	}
});

}(jQuery));

/*
 * This is a "modified" version of Menu, called Drop box.
 *
 * http://docs.jquery.com/UI/Menu
 *
 * Depends:
 *	jquery.ui.core.js
 *  jquery.ui.widget.js
 */
(function($) {

$.widget("ui.dropbox", {
    options: {
        autoRewind: true
    },
	_create: function() {
		var self = this;
        this.mouseX = 0;
        this.mouseY = 0;
		this.element
			.addClass("ui-dropbox")
			.attr({
				role: "listbox",
				"aria-activedescendant": "ui-active-menuitem"
			})
			.click(function(event) {
				if (!$(event.target).closest(".ui-menu-item a").length &&
                        !$(event.target).closest(".NewOption").length) {
					return;
				}
				// temporary
				event.preventDefault();
				self.select( event );
			});
        this.mainList = this.element.find('ul');

        this.newSuggestion = this.element.find('.NewOption');
        this.newSuggestionActive = false;
		this.refresh();
	},

	refresh: function() {
		var self = this;
		this.mainList = this.element.find('ul');

		// don't refresh list items that are already adapted
		var items = this.mainList.children("li:not(.ui-menu-item):has(a)")
			.addClass("ui-menu-item")
			.attr("role", "menuitem");

		items.children("a")
			.addClass("ui-corner-all")
			.attr("tabindex", -1);

        this.mainList.mouseover(function(event) {
            if (self.mouseX && self.mouseY
                && (self.mouseX != event.pageX || self.mouseY != event.pageY)) {
                // Mouse position change
                var me = $(event.target).closest("li.ui-menu-item");
                if (me.length && !me.hasClass("ui-state-hover")) {
                    self.activate(event, me);
                }
            } else if (event.pageX && event.pageY) {
                self.mouseX = event.pageX;
                self.mouseY = event.pageY;
            }
        });
        
        // Special handling for NewOption
        this.newSuggestion
                .removeClass("ui-state-hover")
                .mouseover(function(event) {
                    if (self.mouseX && self.mouseY
                            && (self.mouseX != event.pageX || self.mouseY != event.pageY)
                            && (!$(this).hasClass('ui-state-hover'))) {
                        self.activate(event, $(this));
                    } else if (event.pageX && event.pageY) {
                        self.mouseX = event.pageX;
                        self.mouseY = event.pageY;
                    }
                })
                .mouseleave(function() {
                    if ($(this).hasClass('ui-state-hover')) {
                        self.deactivate();
                    }
                });
	},

    /**
     * We use slightly different hovering logic (hover LI elements, not A links inside them).
     */
	activate: function(event, item) {
		this.deactivate();

        if (item.hasClass('NewOption')) {
            item.eq(0).addClass('ui-state-hover');
            this.active = item;
            this.newSuggestionActive = true;
        } else {
            var _item = item.eq(0).children('a');
            if (this.hasScroll()) {
                var offset = _item.offset().top - this.mainList.offset().top,
                    scroll = this.mainList.attr("scrollTop"),
                    elementHeight = this.mainList.height();
                if (offset < 0) {
                    this.mainList.attr("scrollTop", scroll + offset);
                } else if (offset > elementHeight) {
                    this.mainList.attr("scrollTop", scroll + offset - elementHeight + _item.height());
                }
            }
            item.eq(0).addClass('ui-state-hover');
            this.active = _item.attr("id", "ui-active-menuitem").end();
            this.newSuggestionActive = false;
        }
        this._trigger("focus", event, { item: item });
	},

    /**
     * Again a bit different hovering.
     */
	deactivate: function() {
		if (!this.active) { return; }
        if (!this.newSuggestionActive) {
            this.active.closest('li').removeClass("ui-state-hover");
            this.active.removeAttr("id");
        } else {
            this.active.removeClass("ui-state-hover");
            this.newSuggestionActive = false;
        }
		this._trigger("blur");
		this.active = null;
	},

    next: function(event) {
        this.move("next", ".ui-menu-item:first", event);
    },

    previous: function(event) {
        this.move("prev", ".ui-menu-item:last", event);
    },

	first: function() {
		return this.active && !this.active.prevAll(".ui-menu-item").length;
	},

	last: function() {
		return this.active && !this.active.nextAll(".ui-menu-item").length;
	},

    /** what to do when last item is reached */
    afterLast: function(event) {
        if (this.newSuggestion.is(":visible")) {
            if (this.newSuggestionActive) {
                return true;
            } else {
                this.activate(event, this.newSuggestion);
                return false;
            }
        } else if (this.options.autoRewind) {
            this.activate(event, this.mainList.children(".ui-menu-item:first"));
            return false;
        }
        return true;
    },

    beforeFirst: function(event) {
        if (this.options.autoRewind) {
            this.activate(event, this.mainList.children(".ui-menu-item:last"));
            return false;
        } else if (this.options.autoRewind) {
            this.activate(event, this.mainList.children(".ui-menu-item:first"));
            return false;
        }
        return true;
    },

    move: function(direction, edge, event) {
        if (!this.active) {
            // When no children available, select new option.
            if (this.mainList.children(".ui-menu-item").length == 0) {
                this.activate(event, this.newSuggestion);
            } else {
                this.activate(event, this.mainList.children(edge));
            }
            return;
        }
        var next = this.active[direction + "All"](".ui-menu-item").eq(0);
        if (next.length) {
            this.activate(event, next);
        } else {
            this.activate(event, this.mainList.children(edge));
        }
    },

	// TODO merge with previousPage
	nextPage: function(event) {
		if (this.hasScroll()) {
			// TODO merge with no-scroll-else
			if ((!this.active || this.last()) && !this.options.autoRewind) {
				this.activate(event, this.mainList.children(".ui-menu-item:first"));
				return;
			}
			var base = this.active.offset().top,
				height = this.mainList.height(),
				result = this.mainList.children(".ui-menu-item").filter(function() {
					var close = $(this).offset().top - base - height + $(this).height();
					// TODO improve approximation
					return close < 10 && close > -10;
				});

			// TODO try to catch this earlier when scrollTop indicates the last page anyway
			if (!result.length) {
				result = this.mainList.children(".ui-menu-item:last");
			}
			this.activate(event, result);
		} else {
			this.activate(event, this.mainList.children(".ui-menu-item")
				.filter(((!this.active || this.last()) && !this.options.autoRewind) ? ":first" : ":last"));
		}
	},

	// TODO merge with nextPage
	previousPage: function(event) {
		if (this.hasScroll()) {
			// TODO merge with no-scroll-else
			if ((!this.active || this.first()) && !this.options.autoRewind) {
				this.activate(event, this.mainList.children(".ui-menu-item:last"));
				return;
			}

			var base = this.active.offset().top,
				height = this.mainList.height();
				result = this.mainList.children(".ui-menu-item").filter(function() {
					var close = $(this).offset().top - base + height - $(this).height();
					// TODO improve approximation
					return close < 10 && close > -10;
				});

			// TODO try to catch this earlier when scrollTop indicates the last page anyway
			if (!result.length) {
				result = this.mainList.children(".ui-menu-item:first");
			}
			this.activate(event, result);
		} else {
			this.activate(event, this.mainList.children(".ui-menu-item")
				.filter(((!this.active || this.first()) && !this.options.autoRewind) ? ":last" : ":first"));
		}
	},

	hasScroll: function() {
		return this.mainList.height() < this.mainList.attr("scrollHeight");
	},

	select: function( event ) {
		this._trigger("selected", event, { item: this.active, isNew: this.newSuggestionActive });
	}
});

/**
 * A modification of base lookup widget
 * which allows selecting just one single entity.
 */
Selector.selectOne = function(widgetName, baseWidget) {
$.widget("ui." + widgetName, baseWidget, {
    options: {
        html: true,
        paramName: null,
        selection: null,
        select: function(event, ui) {
            var widget = $(this).data(widgetName);
            widget.selectedIds = {};
            if (ui.isNew) {
                widget._selectNew();
            } else {
                $(this).data("lookup.selection", ui.item.value);
                widget.fieldId.val(ui.item.id);
                if (widget.options.paramNameNew) {
                    widget.fieldNew.val('');
                }
                widget.newOptionIndicator.hide();
                widget.selectedIds[parseInt(ui.item.id)] = true;
            }
            widget._trigger("selectItem", event, ui);
            return true;
        },

        currentSelection: function() {
            if (this.fieldId.val()) {
                var r = {};
                r[parseInt(this.fieldId.val())] = true;
                return r;
            } else {
                return {};
            }
        }

    },

    _create: function() {
        var self = this;
        baseWidget.prototype._create.apply(this, arguments);
        this.fieldId = $('<input type="hidden"/>')
                .attr("name", this.options.paramName)
                .val((this.options.selection && !this.options.selection.isNew) ? this.options.selection.id : '')
                .appendTo(this.rootElement);
        if (this.options.paramNameNew) {
            this.fieldNew = $('<input type="hidden"/>')
                    .attr("name", this.options.paramNameNew)
                    .val((this.options.selection && this.options.selection.isNew) ? this.options.selection.value : '')
                    .appendTo(this.rootElement);
        }
        var flag = $('<div class="NewOptionFlag"></div>')
            .text(this.options.messages.newFlag)
            .hide()
            .appendTo(this.rootElement);
        if (!this.options.selection && this.element.val() != '' && !this.element.hasClass("withHelperEnabled")) {
            flag.show();
        }
        this.newOptionIndicator = flag;
        if (this.options.selection) {
            this.element.val(this.options.selection.value).removeClass('withHelperEnabled');
            if (this.options.selection.isNew) {
                this._selectNew();
                this.newOptionIndicator.show();
            }
        }
        this.element.keypress(function(event) {
            var keyCode = $.ui.keyCode;
            // todo clear hidden??
            if (event.charCode != 0 || event.keyCode == keyCode.DELETE || event.keyCode == keyCode.BACKSPACE) {
                self._clearNewOption();
            }
        });
    },

    destroy: function() {
        $.ui.lookup.prototype.destroy.call(this);
    },

    /**
     * Override _change to clear selection when user goes away.
     * @param event
     */
    _change: function(event) {
        baseWidget.prototype._change.apply(this, [event]);
        var mySelection = this.element.data("lookup.selection");
        if ((!mySelection || (mySelection != this.element.val() || this.fieldId.val() == '')) && (!this.options.paramNameNew || this.fieldNew.val() == '')) {
            // No selection.
            this._clearSelection();
        }
    },

    /**
     * Returns current selection value.
     * This only applies to existing items.
     */
    currentSelection: function() {
        return this.fieldId.val();
    },

    _clearNewOption: function() {
        this.newOptionIndicator.hide();
        if (this.options.paramNameNew) {
            this.fieldNew.val('');
        }
    },

    _clearSelection: function() {
        this.fieldId.val('');
        this.element.addClass("withHelperEnabled").val(this.element.attr("helperValue"));
        this._clearNewOption();
    },

    _selectNew: function() {
        this.fieldId.val('');
        if (this.options.paramNameNew) {
            this.fieldNew.val(this.element.val());
        }
        this.newOptionIndicator.show();
    }
});

};  // Selector.selectOne

/**
 * A modification of base lookup widget
 * which allows selecting multi entities, with many hidden fields.
 *
 * The widget assumes that all identifiers are integer.
 */
Selector.selectMany = function(widgetName, baseWidget) {
$.widget("ui." + widgetName, baseWidget, {
    options: {
        html: true,
        paramName: 'selectMany',
        paramNameNew: 'selectManyNew',
        clearOnSelect: true,

        /**
         * When item is selected, append new element to the list.
         */
        select: function(event, ui) {
            var widget = $(this).data(widgetName);
            widget.options.renderSelectedItem.apply(widget, [widget.itemsBlock, ui.item, ui.isNew]);
            widget._onSelect(ui.item);
            widget._trigger("selectItem", event, ui);
            return !widget.options.clearOnSelect;
        },

        /**
         * Render new selected item.
         */
        renderSelectedItem: function(itemsBlock, item, isNew) {
            var self = this;
            var content = $("<input type=\"hidden\"/>");
            if (isNew) {
                content
                        .attr("name", this.options.paramNameNew)
                        .val(item.value);
            } else {
                content
                        .attr("name", this.options.paramName)
                        .addClass("SelectorTarget")
                        .val(item.id);
            }
            if (!isNew) {
                self.selectedIds[parseInt(item.id)] = true;
            }
            return $("<li></li>")
                    .addClass()
                    .append($("<a></a>")
                            .addClass("deleteElement")
                            .attr("href", "#")
                            .html("&nbsp;")
                            .click(function(evt) { self._deleteBlock(this, evt); return false; })
                    )
                    .append($("<span></span>").addClass("SelectedItemName").text(item.value))
                    .append(content)
                    .data("item", item)
                    .appendTo(itemsBlock);
        }
    },

    _create: function() {
        var self = this;
        baseWidget.prototype._create.apply(this, arguments);
        if (this.options.items) {
            this.itemsBlock = $(this.options.items);
        } else {
            // Generate items block
            this.itemsBlock = $('<ul class="SelectedItems"></ul>').insertBefore(this.rootElement);
        }
        if (this.options.selection) {
            this.replaceAllItems(this.options.selection);
        }
        // Initialize selected ids.
        this.selectedIds = {};
        this.itemsBlock.find('li input[name=' + jQuerySelectorEscape(this.options.paramName) + ']').each(function(index, item) {
            self.selectedIds[parseInt($(item).val())] = true;
        });
    },

    _deleteBlock: function(block, event) {
        var id = $(block).closest("li").find("input[name=" + jQuerySelectorEscape(this.options.paramName) + "]").val();
        if (id) {
            this._onDeselect(id);
            delete this.selectedIds[parseInt(id)];
        }
        var item = $(block).closest('li').data("item");
        $(block).closest('li').remove();
        this._trigger("deselectItem", event, {item:item});
    },

    /** Update "selected" status */
    _onSelect: function(item) {

    },
    _onDeselect: function(id) {

    },

    /**
     * Remove selected item from the list by id.
     * @param id item internal id (application id, not a DOM id!)
     */
    deleteItem: function(id) {
        this.itemsBlock.find('li input.SelectorTarget[value=' + id + ']').closest('li').remove();
        delete this.selectedIds[parseInt(id)];
    },

    /**
     * Deselect all items, including new.
     */
    clearItems: function() {
        this.itemsBlock.empty();
        this.selectedIds = {};
    },

    /**
     * Completely replace all selected items with the provided list.
     */
    replaceAllItems: function(items) {
        this.itemsBlock.empty();
        this.selectedIds = {};
        for(var i = 0; i < items.length; i++) {
            var item = items[i];
            this.selectedIds[parseInt(item.id)] = true;
            this.options.renderSelectedItem.apply(this, [this.itemsBlock, item, item.isNew]);
        }
    }
});

};  // Selector.selectMany

// Register selectOne widget.
Selector.selectOne("selectOne", $.ui.lookup);
// Register selectMany widget.
Selector.selectMany("selectMany", $.ui.lookup);

}(jQuery));