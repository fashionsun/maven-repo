var treeCombo = {
    nodeCount: 0,
    allowsHiding: true //(!jQuery.browser.msie || parseInt(jQuery.browser.version) > 7)
};
treeCombo.TreeNode = function(oItem, oParent) {
    this.init(oItem, oParent);
};

treeCombo.TreeNode.prototype = {

    /**
     * The index for this instance obtained from global counter in treeCombo.
     * @property index
     * @type int
     */
    index: 0,

    /**
     * This node's child node collection.
     * @property children
     * @type TreeNode[]
     */
    children: null,

    /**
     * Tree instance this node is part of
     * @property tree
     * @type treeCombo
     */
    tree: null,

    /**
     * The data linked to this node.  This can be any object or primitive
     * value, and the data can be used in getNodeHtml().
     * @property data
     * @type object
     */
    data: null,

    /**
     * Parent node
     * @property parent
     * @type TreeNode
     */
    parent: null,

    /**
     * The depth of this node.  We start at -1 for the root node.
     * @property depth
     * @type int
     */
    depth: -1,

    /**
     * The node's expanded/collapsed state
     * @property expanded
     * @type boolean
     */
    expanded: false,

    /**
     * Node visible?
     * Nodes may occasionally be hidden by search filtering.
     */
    visible: true,

    /**
     * Can multiple children be expanded at once?
     * @property multiExpand
     * @type boolean
     */
    multiExpand: true,

    /**
     * Should we render children for a collapsed node?  It is possible that the
     * implementer will want to render the hidden data...  @todo verify that we
     * need this, and implement it if we do.
     * @property renderHidden
     * @type boolean
     */
    renderHidden: false,

    /**
     * This flag is set to true when the html is generated for this node's
     * children, and set to false when new children are added.
     * @property childrenRendered
     * @type boolean
     */
    childrenRendered: false,

    /**
     * Dynamically loaded nodes only fetch the data the first time they are
     * expanded.  This flag is set to true once the data has been fetched.
     * @property dynamicLoadComplete
     * @type boolean
     */
    dynamicLoadComplete: false,

    /**
     * This node's previous sibling
     * @property previousSibling
     * @type Node
     */
    previousSibling: null,

    /**
     * This node's next sibling
     * @property nextSibling
     * @type Node
     */
    nextSibling: null,

    /**
     * We can set the node up to call an external method to get the child
     * data dynamically.
     * @property _dynLoad
     * @type boolean
     * @private
     */
    _dynLoad: false,

    /**
     * Function to execute when we need to get this node's child data.
     * @property dataLoader
     * @type function
     */
    dataLoader: null,

    /**
     * This is true for dynamically loading nodes while waiting for the
     * callback to return.
     * @property isLoading
     * @type boolean
     */
    isLoading: false,

    /**
     * The toggle/branch icon will not show if this is set to false.  This
     * could be useful if the implementer wants to have the child contain
     * extra info about the parent, rather than an actual node.
     * @property hasIcon
     * @type boolean
     */
    hasIcon: true,

    /**
     * Used to configure what happens when a dynamic load node is expanded
     * and we discover that it does not have children.  By default, it is
     * treated as if it still could have children (plus/minus icon).  Set
     * iconMode to have it display like a leaf node instead.
     * @property iconMode
     * @type int
     */
    iconMode: 0,

    /**
     * Specifies whether or not the content area of the node should be allowed
     * to wrap.
     * @property nowrap
     * @type boolean
     * @default false
     */
    nowrap: false,

 /**
     * If true, the node will alway be rendered as a leaf node.  This can be
     * used to override the presentation when dynamically loading the entire
     * tree.  Setting this to true also disables the dynamic load call for the
     * node.
     * @property isLeaf
     * @type boolean
     * @default false
     */
    isLeaf: false,

/**
     * The CSS class for the html content container.  Defaults to ygtvhtml, but
     * can be overridden to provide a custom presentation for a specific node.
     * @property contentStyle
     * @type string
     */
    contentStyle: "",


    /**
     * The generated id that will contain the data passed in by the implementer.
     * @property contentElId
     * @type string
     */
    contentElId: null,

/**
 * Enables node highlighting.  If true, the node can be highlighted and/or propagate highlighting
 * @property enableHighlight
 * @type boolean
 * @default true
 */
    enableHighlight: true,

/**
 * Stores the highlight state.  Can be any of:
 * <ul>
 * <li>0 - not highlighted</li>
 * <li>1 - highlighted</li>
 * <li>2 - some children highlighted</li>
 * </ul>
 * @property highlightState
 * @type integer
 * @default 0
 */

 highlightState: 0,

 /**
 * Tells whether highlighting will be propagated up to the parents of the clicked node
 * @property propagateHighlightUp
 * @type boolean
 * @default false
 */

 propagateHighlightUp: false,

 /**
 * Tells whether highlighting will be propagated down to the children of the clicked node
 * @property propagateHighlightDown
 * @type boolean
 * @default false
 */

 propagateHighlightDown: false,

 /**
  * User-defined className to be added to the Node
  * @property className
  * @type string
  * @default null
  */

 className: null,

 /**
     * The node type
     * @property _type
     * @private
     * @type string
     * @default "Node"
*/
    _type: "Node",

    /**
     * Search label is displayed when highlighting search results.
     */
    searchLabel: null,

    /*
    spacerPath: "http://l.yimg.com/a/i/space.gif",
    expandedText: "Expanded",
    collapsedText: "Collapsed",
    loadingText: "Loading",
    */

    /**
     * Initializes this node, gets some of the properties from the parent
     * @method init
     * @param oData {object} an object containing the data that will (IMMUTABLE!)
     * be used to render this node
     * @param oParent {Node} this node's parent node
     */
    init: function(oItem, oParent) {
        this.data = oItem;
        this.label = oItem.label;
        this.children = [];
        this.index = parseInt(oItem.id);
        this.isLeaf = oItem.leaf;
        // PRevent from modifying a possibly-shared item.
//        delete oItem.leaf;
        //++treeCombo.nodeCount;
        // oParent should never be null except when we create the root node.
        if (oParent) {
            oParent.appendChild(this);
        }
    },

    getId: function() {
        return this.index;
    },
    
    /**
     * Certain properties for the node cannot be set until the parent
     * is known. This is called after the node is inserted into a tree.
     * the parent is also applied to this node's children in order to
     * make it possible to move a branch from one tree to another.
     * @method applyParent
     * @param {Node} parentNode this node's parent node
     * @return {boolean} true if the application was successful
     */
    applyParent: function(parentNode) {
        if (!parentNode) {
            return false;
        }

        this.tree   = parentNode.tree;
        this.parent = parentNode;
        this.depth  = parentNode.depth + 1;

        // @todo why was this put here.  This causes new nodes added at the
        // root level to lose the menu behavior.
        // if (! this.multiExpand) {
            // this.multiExpand = parentNode.multiExpand;
        // }

//        this.tree.regNode(this);
        parentNode.childrenRendered = false;

        // cascade update existing children
        for (var i=0, len=this.children.length;i<len;++i) {
            this.children[i].applyParent(this);
        }

//        this.fireEvent("parentChange");

        return true;
    },

    /**
     * Appends a node to the child collection.
     * @method appendChild
     * @param childNode {Node} the new node
     * @return {Node} the child node
     * @private
     */
    appendChild: function(childNode) {
        if (this.hasChildren()) {
            var sib = this.children[this.children.length - 1];
            sib.nextSibling = childNode;
            childNode.previousSibling = sib;
        }
        this.children[this.children.length] = childNode;
        childNode.applyParent(this);

        // part of the IE display issue workaround. If child nodes
        // are added after the initial render, and the node was
        // instantiated with expanded = true, we need to show the
        // children div now that the node has a child.
        if (this.childrenRendered && this.expanded) {
//            this.getChildrenEl().style.display = "";
        }

        return childNode;
    },

    /**
     * Appends this node to the supplied node's child collection
     * @method appendTo
     * @param parentNode {Node} the node to append to.
     * @return {Node} The appended node
     */
    appendTo: function(parentNode) {
        return parentNode.appendChild(this);
    },

    /**
     * Checks if this node has children.  If this node is lazy-loading and the
     * children have not been rendered, we do not know whether or not there
     * are actual children.  In most cases, we need to assume that there are
     * children (for instance, the toggle needs to show the expandable
     * presentation state).  In other times we want to know if there are rendered
     * children.  For the latter, "checkForLazyLoad" should be false.
     * @method hasChildren
     * @param checkForLazyLoad {boolean} should we check for unloaded children?
     * @return {boolean} true if this has children or if it might and we are
     * checking for this condition.
     */
    hasChildren: function(checkForLazyLoad) {
        if (this.isLeaf) {
            return false;
        } else {
            return (this.children.length > 0 ||
                (checkForLazyLoad && this.isDynamic() && !this.dynamicLoadComplete)
            );
        }
    },
    
    /**
     * Evaluates if this node's children should be loaded dynamically.  Looks for
     * the property both in this instance and the root node.  If the tree is
     * defined to load all children dynamically, the data callback function is
     * defined in the root node
     * @method isDynamic
     * @return {boolean} true if this node's children are to be loaded dynamically
     */
    isDynamic: function() {
        if (this.isLeaf) {
            return false;
        } else {
            return (!this.isRoot() && (this._dynLoad || this.tree.root._dynLoad));
            // return lazy;
        }
    },

    /**
     * Shows this nodes children (creating them if necessary), changes the
     * toggle style, and collapses its siblings if multiExpand is not set.
     * @method expand
     */
    expand: function(lazySource) {
        // Only expand if currently collapsed.
        if (this.isLoading || (this.expanded && !lazySource)) {
            return;
        }

        var ret = true;

        // When returning from the lazy load handler, expand is called again
        // in order to render the new children.  The "expand" event already
        // fired before fething the new data, so we need to skip it now.
        if (!lazySource) {
            // note: cannot stop expand from event handler...
            this.tree._trigger("expand", [this]);
        }

        if (!this.getEl()) {
            this.expanded = true;
            return;
        }

        if (!this.childrenRendered) {
            this.renderChildren();
        }

        this.expanded = true;

        this.updateIcon();

        // this.getSpacer().title = this.getStateText();

        // We do an extra check for children here because the lazy
        // load feature can expose nodes that have no children.

        // if (!this.hasChildren()) {
        if (this.isLoading) {
            this.expanded = false;
            return;
        }

        if (!this.multiExpand) {
            var sibs = this.getSiblings();
            for (var i=0; sibs && i<sibs.length; ++i) {
                if (sibs[i] != this && sibs[i].expanded) {
                    sibs[i].collapse();
                }
            }
        }

        this.showVisibleChildren();

        ret = this.tree._trigger("expandComplete", [this]);
    },

    /**
     * Hides this nodes children (creating them if necessary), changes the toggle style.
     * @method collapse
     */
    collapse: function() {
        // Only collapse if currently expanded
        if (!this.expanded) { return; }

        this.tree._trigger("collapse", this);

        if (!this.getEl()) {
            this.expanded = false;
        } else {
            // hide the child divs
            if (this.hasChildren()) {
                if (treeCombo.allowsHiding) {
                    for(var i=0, len=this.children.length;i<len;++i) {
                        this.children[i].collapse();
                        // Hide child but keep it visible.
                        this.children[i].hideTemporary();
                    }
                } else {
                    // Have to remove all children. IE7.
                    for(var i=0, len=this.children.length;i<len;++i) {
                        this.children[i].destroy();
                    }
                    this.childrenRendered = false;
                }
            }
            this.expanded = false;

            this.updateIcon();
        }

        // this.getSpacer().title = this.getStateText();

        this.tree._trigger("collapseComplete", this);
    },
    
    /**
     * Evaluates if this node is the root node of the tree
     * @method isRoot
     * @return {boolean} true if this is the root node
     */
    isRoot: function() {
        return (this == this.tree.root);
    },

    
    destroy: function() {
        if (this._el) {
            this._el.remove();
            this._el = null;
        }
        this.visible = false;
        this.expanded = false;
        this.dynamicLoadComplete = false;
        this.isLoading = false;
    },

    /**
     * Returns the tree's host element
     * @method getEl
     * @return {HTMLElement} the host element
     */
    getEl: function() {
//        if (! this._el) {
//            this._el = Dom.get(this.id);
//        }
        return this._el;
    },

    /**
     * Returns the div that was generated for this node's children
     * @method getChildrenEl
     * @return {HTMLElement} this node's children div
     */
    getChildrenEl: function() {
        return this._el.children("ul")[0];
    },


    /**
     * Generates the markup for the child nodes.  This is not done until the node
     * is expanded.
     * @method renderChildren
     * @return {string} the html for this node's children
     * @private
     */
    renderChildren: function() {

        var node = this;

        if (this.isDynamic() && !this.dynamicLoadComplete && !this.isSearchMode()) {
            this.isLoading = true;
            this.tree.locked = true;

            if (this.tree.dataLoader) {
                this.tree.dataLoader.apply(this.tree, [node, function() { node.loadComplete(); }]);
            } else {
                return "Error: data loader not found or not specified.";
            }

        } else {
            this.completeRender();
        }
    },

    /**
     * Called when we know we have all the child data.
     * @method completeRender
     * @return {jQuery} children UL element
     */
    completeRender: function() {
        var offset = ((this.depth + 1) * 16) + 'px';
        var el = $(this.getEl());
        for(var i=0, len=this.children.length;i<len;++i) {
            var childEl = this.children[i].render();
            childEl.find('.indent').css('margin-left', offset);
            el.after(childEl);
            el = childEl;
        }
        if (!this.isSearchMode()) {
            this.childrenRendered = true;
        }
    },

    /**
     * Load complete is the callback function we pass to the data provider
     * in dynamic load situations.
     * @method loadComplete
     */
    loadComplete: function() {
        this.completeRender();
        if (this.propagateHighlightDown) {
            if (this.highlightState === 1 && !this.tree.singleNodeHighlight) {
                for (var i = 0; i < this.children.length; i++) {
                this.children[i].highlight(true);
            }
            } else if (this.highlightState === 0 || this.tree.singleNodeHighlight) {
                for (i = 0; i < this.children.length; i++) {
                    this.children[i].unhighlight(true);
                }
            } // if (highlighState == 2) leave child nodes with whichever highlight state they are set
        }

        this.dynamicLoadComplete = true;
        this.isLoading = false;
        this.expand(true);
        this.tree.locked = false;
    },

    /**
     * Shows this node's children
     * @method showChildren
     */
    showChildren: function() {
        if (!this.tree.animateExpand(this.getEl(), this)) {
            if (this.hasChildren()) {
                for(var i=0, len=this.children.length;i<len;++i) {
                    this.children[i].show();
                }
            }
        }
    },

    /**
     * Shows this node's visible children. This is used during expand.
     * @method showVisibleChildren
     */
    showVisibleChildren: function() {
        if (!this.tree.animateExpand(this.getEl(), this)) {
            if (this.hasChildren()) {
                for(var i=0, len=this.children.length;i<len;++i) {
                    if (this.children[i].visible) {
                        this.children[i].show();
                    }
                }
            }
        }
    },

    /**
     * Hides this node's children
     * @method hideChildren
     */
    hideChildren: function() {
        if (!this.tree.animateCollapse(this.getEl(), this)) {
            for(var i=0, len=this.children.length;i<len;++i) {
                this.children[i].hide();
            }
        }
    },

    /**
     * Hide all descendants.
     * Mark all nodes as "Search Mode" to disable normal expand.
     */
    enableSearchMode: function() {
        if (this.hasChildren()) {
            for(var i=0, len=this.children.length;i<len;++i) {
                this.children[i].enableSearchMode();
                this.children[i].expanded = false;
                this.children[i].visible = false;
                this.children[i].updateIcon();
            }
        }
    },

    isSearchMode: function() {
        return this.tree._searchMode;
    },

    /**
     * Show all descendants.
     * Does not actually show children, instead marks them as visible.
     */
    disableSearchMode: function() {
        if (this.hasChildren()) {
            for(var i=0, len=this.children.length;i<len;++i) {
                this.children[i].disableSearchMode();
                this.children[i].visible = true;
                this.children[i].collapse();
            }
        }
        $(this.getEl()).removeClass("ui-search-result");
    },

    /**
     * Just show the damn node.
     */
    show: function() {
        this.visible = true;
        $(this.getEl()).show();
    },

    /**
     * Just hide the damn node.
     */
    hide: function() {
        this.visible = false;
        this.hideTemporary();
    },

    /**
     * Hide element but keep the node visible.
     */
    hideTemporary: function() {
        $(this.getEl()).hide();
    },

    /**
     * Expands if node is collapsed, collapses otherwise.
     * @method toggle
     */
    toggle: function() {
        if (!this.tree.locked && ( this.hasChildren(true) || this.isDynamic()) ) {
            if (this.expanded) { this.collapse(); } else { this.expand(); }
        }
    },

    // Currenty does nothing.
    updateIcon: function() {
        if (this._el) {
            var icon = $(this._el).children("span.button");
            if (this.isDynamic() && this.isLoading && !this.dynamicLoadComplete) {
                icon.removeClass("Collapsed").removeClass("Expanded").addClass("Loading");
            } else {
                icon.removeClass("Loading");
                if (this.isLeaf) {
                    icon.removeClass("Collapsed").removeClass("Expanded");
                } else {
                    if (this.expanded) {
                        icon.removeClass("Collapsed").addClass("Expanded");
                    } else {
                        icon.removeClass("Expanded").addClass("Collapsed");
                    }
                }
            }
        }
    },

    /**
     * Set temporary search label.
     */
    setSearchLabel: function(label) {
        this.searchLabel = label;
        if (label) {
            if (this.getEl()) {
                $(this.getEl()).addClass("ui-search-result").find("a span.label").html(label);
            }
        } else {
            // on empty label, clear away
            if (this.getEl()) {
                $(this.getEl()).removeClass("ui-search-result").find("a span.label").html(this.label);
            }
        }
    },

    setLabel: function(label) {
        this.searchLabel = null;
        this.label = label;
        if (this.getEl()) {
            $(this.getEl()).addClass("ui-search-result").find("a span.label").html(label);
        }
    },

    /**
     * Render node, returning jQuery object.
     */
    render: function() {
        var el = $("<li></li>").addClass("ui-menu-item");
        el.data("item.lookup", this.data);
        var indent = $("<span class=\"indent\"></span>");
        el.append(indent);
        var icon = $("<span class=\"button\"></span>").html('&nbsp;');
        icon.attr("rel", this.getId());
        if (this.parent) {
            el.attr("_parent", this.parent.getId());
        }
        if (this.hasChildren(true)) {
            if (!this.isLeaf) {
                icon.addClass("Collapsed");
            } else {
                icon.addClass("Expanded");
            }
        }
        el.append(icon);
        el.data("item.lookup", this.data);
        var label = $("<span class=\"label\"></span>").html(this.searchLabel ? this.searchLabel : this.label);
        el.append($("<a></a>")
                .attr("href", "#")
                .append(label));
//                .html(this.searchLabel ? this.searchLabel : this.datalabel));
//        if (!this.isLeaf) {
//            el.append($("<ul></ul>"));
//        }
        this._el = el;
        if (!this.visible) {
            el.hide();
        }
        return el;
    }

};

/**
 * A custom treeCombo.TreeNode that handles the unique nature of
 * the virtual, presentationless root node.
 * @class RootNode
 * @extends treeCombo.TreeNode
 * @param oTree {$.ui.treeCombo} The tree instance this node belongs to
 * @constructor
 */
treeCombo.RootNode = function(oTree) {
    // Initialize the node with null params.  The root node is a
    // special case where the node has no presentation.  So we have
    // to alter the standard properties a bit.
    this.init({id:0}, null, true);

    /*
     * For the root node, we get the tree reference from as a param
     * to the constructor instead of from the parent element.
     */
    this.tree = oTree;
};

$.extend(treeCombo.RootNode.prototype, treeCombo.TreeNode.prototype, {
   /**
     * The node type
     * @property _type
      * @type string
     * @private
     * @default "RootNode"
     */
    _type: "RootNode",

    /**
     * In search mode, nodes are never loaded dynamically.
     */
    searchMode: false,

    // overrides YAHOO.widget.Node
    getNodeHtml: function() {
        return "";
    },

    toString: function() {
        return this._type;
    },

    loadComplete: function() {
        this.tree.draw();
    },

   /**
     * Count of nodes in tree.
    * It overrides Nodes.getNodeCount because the root node should not be counted.
     * @method getNodeCount
     * @return {int} number of nodes in the tree
     */
    getNodeCount: function() {
        for (var i = 0, count = 0;i< this.children.length;i++) {
            count += this.children[i].getNodeCount();
        }
        return count;
    },

    /**
     * Configures this node for dynamically obtaining the child data
     * when the node is first expanded.  Calling it without the callback
     * will turn off dynamic load for the node.
     * @method setDynamicLoad
     * @param fmDataLoader {function} the function that will be used to get the data.
     * @param iconMode {int} configures the icon that is displayed when a dynamic
     * load node is expanded the first time without children.  By default, the
     * "collapse" icon will be used.  If set to 1, the leaf node icon will be
     * displayed.
     */
    setDynamicLoad: function(fnDataLoader, iconMode) {
        if (fnDataLoader) {
            this.dataLoader = fnDataLoader;
            this._dynLoad = true;
        } else {
            this.dataLoader = null;
            this._dynLoad = false;
        }

        if (iconMode) {
            this.iconMode = iconMode;
        }
    },

    /**
     * Returns an object which could be used to build a tree out of this node and its children.
     * It can be passed to the tree constructor to reproduce this node as a tree.
     * Since the RootNode is automatically created by treeView,
     * its own definition is excluded from the returned node definition
     * which only contains its children.
     * @method getNodeDefinition
     * @return {Object | false}  definition of the tree or false if any child node is defined as dynamic
     */
    getNodeDefinition: function() {

        for (var def, defs = [], i = 0; i < this.children.length;i++) {
            def = this.children[i].getNodeDefinition();
            if (def === false) { return false;}
            defs.push(def);
        }
        return defs;
    },

    render: function() {
        var ul = $("<ul></ul>");
        for (var i=0, len=this.children.length;i<len;++i) {
            ul.append(this.children[i].render());
        }
        this.childrenRendered = true;
        this._el = ul;
        return ul;
    },


    collapse: function() {},
    expand: function() {},
    getSiblings: function() { return null; },
    focus: function () {},

    disableSearchMode: function() {
        for (var i = 0, len = this.children.length; i < len; ++i) {
            this.children[i].disableSearchMode();
            this.children[i].visible = true;
            this.children[i].collapse();
        }
        $(this.getEl()).removeClass("ui-search-result");
        this.tree._searchMode = false;
    },

    enableSearchMode: function() {
        for(var i=0, len=this.children.length;i<len;++i) {
            this.children[i].enableSearchMode();
            this.children[i].expanded = false;
            this.children[i].visible = false;
            this.children[i].updateIcon();
        }
        this.tree._searchMode = true;
    }

});


(function($, undefined) {

$.widget("ui.treeCombo", $.ui.lookup, {
	options: {
	    dynamicLoad: true,
        preloadRoot: true,
	    box: "treebox",

        /** Make a special AJAX call adding "dynamic" param. */
        source: function(request, response) {
            var self = this;
            var ajaxOptions = {
                // ! using 'context' will cause stack overflow in IE7, see GC-28
                url: self.options.url,
                cache: true,
                ifModified: true,
                dataType: "json",
                data: { term: request.term, dynamic: self.options.dynamicLoad },
                success: function(data) {
                    response(data[self.options.jsonList], data.newSuggestion);
                    self.stopProgress();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if (textStatus != 'abort' && textStatus != 'error') {
                         (textStatus + '/' + errorThrown);
                    }
                    self.stopProgress();
                }
            };
            this.options.parameterize.apply(this, [ajaxOptions]);
            // if dynamicLoad is disabled and we don't have a tree yet... wait.
            self._fullTree.promise().done(function() {
                $.ajax(ajaxOptions);
            });
        }
    },
    
     /**
     * Flat collection of all nodes in this tree.  This is a sparse
     * array, so the length property can't be relied upon for a
     * node count for the tree.
     * @property _nodes
     * @type treeCombo.TreeNode[]
     * @private
     */
    _nodes: null,

    /**
     * We lock the tree control while waiting for the dynamic loader to return
     * @property locked
     * @type boolean
     */
    locked: false,

    /**
     * true when the complete tree is loading.
     * @property treeLoading
     * @type boolean
     */
    treeLoading: false,

    /**
     * The animation to use for expanding children, if any
     * @property _expandAnim
     * @type string
     * @private
     */
    _expandAnim: null,

    /**
     * The animation to use for collapsing children, if any
     * @property _collapseAnim
     * @type string
     * @private
     */
    _collapseAnim: null,

    /**
     * The current number of animations that are executing
     * @property _animCount
     * @type int
     * @private
     */
    _animCount: 0,

    /**
     * The maximum number of animations to run at one time.
     * @property maxAnim
     * @type int
     */
    maxAnim: 2,

    /**
     * Dynamically load the tree?
     * @property _dynLoad
     * @type boolean
     * @private
     */
    _dynLoad: false,

    /**
     * Full tree deferred, used when dynamic load is not enabled.
     */
    _fullTree: null,

    /**
     * Search mode: when true, only search hits and parents are visible.
     */
    _searchMode: false,

    /**
     * Dirty items with search labels
     */
    _dirtyNodes: [],

    /**
     * Widget Constructor.
     */
	_create: function() {

        this._fullTree = new $.Deferred();

        var self = this;
        $.ui.lookup.prototype._create.apply(this, arguments);
        this.rootElement.addClass('TreeSelector');

        // Apply additional clicker for buttons.
        this.menu.element.click(function(event) {
            if ($(event.target).closest("span.button").length) {
                // Find a node
                var item = $(event.target).closest("li.ui-menu-item").data("item.lookup");
                var node = self.getNodeById(parseInt(item.id));
                node.toggle();
                // For IE7 resize menu again...
                self._resizeMenu();
                return false;
            }
            return true;
        });

		// Load nodes.
        this._nodes = [];

        // Set up the root node
        this.root = new treeCombo.RootNode(this);
        if (this.options.dynamicLoad) {
            this.root.setDynamicLoad(this.dataLoader);
        }

        this.menu.tree = this;

//        if (!this.options.dynamicLoad) {
        if (this.options.preloadRoot) {
            this._preloadRoot();
        }

            // Start loading a tree immediately.
//            var self = this;
//            this._fullTree.promise().always(function() { self.stopProgress(); });
//            // Callback to render a tree when done.
//            this._fullTree.promise().done(function(tree) {
//                self._buildTreeFromJSON(tree);
//                self.menu.element.find('ul').replaceWith(self.getRoot().render());
//            });
//
//            // Load a tree.
//            if (this._getCachedResponse('')) {
//                self._fullTree.resolve(this._getCachedResponse('')[0]);
//            } else {
//            }
//        }
    },


    /**
     * Starts deferred loading of root nodes.
     */
    _preloadRoot: function() {
        var self = this;
        this._getDeferredResponse('', function(treeDeferred) {
            // Start loading full-tree when not available
            self.treeLoading = true;
            self.startProgress();
            var ajaxOptions = {
                // ! using 'context' will cause stack overflow in IE7, see GC-28
                url: self.options.url,
                cache: true,
                ifModified: true,
                dataType: "json",
                // For dynamicLoad = true, preload root.
                data: { term: '', dynamic: self.options.dynamicLoad },
                success: function(data, textStatus, jqXHR) {
                    treeDeferred.resolve([data[self.options.jsonList]]);
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    // AJAX abort triggers "error", not "abort". Damn.
                    if (textStatus != 'abort' && textStatus != 'error') {
                        alert(errorThrown + "\n" + textStatus);
                    }
                    alert('error')
                    treeDeferred.reject();
                },
                complete: function() { self.stopProgress(); }
            };
            self.options.parameterize.apply(self, [ajaxOptions]);
            $.ajax(ajaxOptions);
        }).promise().done(function(result) {
            var tree = result[0];
            self._buildTreeFromJSON(tree);
            self.menu.element.find('ul').replaceWith(self.getRoot().render());
            // Callback to render a tree when done.
            self._fullTree.resolve(tree);
        }).fail(function() { self._fullTree.reject(); });
    },

    /**
     * Returns the root node of this tree
     * @method getRoot
     * @return {Node} the root node
     */
    getRoot: function() {
        return this.root;
    },

    /**
     * Count of nodes in tree
     * @method getNodeCount
     * @return {int} number of nodes in the tree
     */
    getNodeCount: function() {
        return this.getRoot().getNodeCount();
    },

    /**
     * Suppress re-search when menu is hidden
     * @param direction
     * @param event
     */
    _move: function(direction, event) {
        if (this.treeLoading) {
            return;
        } else {
            $.ui.lookup.prototype._move.apply(this, arguments);
        }
    },

    /**
     * Build node objects from the given JSON.
     */
    _buildTreeFromJSON: function(items) {
        var itemsWithoutParent = new Array();
        for(var i = 0; i < items.length; i++) {
            var item = items[i];
            var id = parseInt(item.id);
            var node = this._nodes[id];
            if (!node) {
                // Create new node.
                var parent;
                if (item.parent != undefined) {
                    var parentId = parseInt(item.parent);
                    parent = this._nodes[parentId];
                    if (!parent) {
                        // This node wants parent. Register it.
                        itemsWithoutParent.push(item);
                    }
                } else {
                    parent = this.root;
                }
                node = new treeCombo.TreeNode(item, parent);
                this._nodes[id] = node;
            } else {
                // if node already exists, update label.
                if (!this._searchMode) {
                    node.setLabel(item.label);
                }
            }
        }

        // Scan through waitlist and assign parents...
        for(i = 0; i < itemsWithoutParent.length; i++) {
            var item = itemsWithoutParent[i];
            var id = parseInt(item.id);
            var parentId = parseInt(item.parent);
            var parent = this._nodes[parentId];
            if (!parent) {
                alert("Node " + id + " has no parent: " + parentId);
                throw "No parent";
            }
            parent.appendChild(this.getNodeById(id));
            // DO NOT modify item which possibly shared.
            //delete item.parent;
        }
    },

    /**
     * Returns a node in the tree that has the specified id.
     * @method getNodeById
     * @param {int} nodeIndex the index of the node wanted
     * @return {Node} the node with index=nodeIndex, null if no match
     */
    getNodeById: function(nodeIndex) {
        var n = this._nodes[nodeIndex];
        return (n) ? n : null;
    },


    /**
     *
     * @param ul
     * @param items
     * @param newSuggestion
     */
    _renderMenu: function(ul, items, newSuggestion) {
        var self = this;
        var currentSelection = this.options.currentSelection.apply(this, []);

        // What if we get a search query and still don't have a tree?
        if (!this.getRoot().childrenRendered) {
            
            if (this.term == '' && !this.options.dynamicLoad && !this.options.preloadRoot) {
                this._buildTreeFromJSON(items);
            }

            //this._buildTreeFromJSON(items);
            // Render tree.
            ul.replaceWith(this.getRoot().render());
        }

        if (this.term != '') {
            this.getRoot().enableSearchMode();
        }

        if (this.options.dynamicLoad) {
            this._buildTreeFromJSON(items);
        }
        
        // Clear any search labels...
        this._clearSearchHighlighting();

        if (this.term != '') {
            // show search results

            // 1. Expand all nodes (to make sure they're all rendered)
            // For every result we get, show the associated node and all its parents.
            var nodesToExpand = new Array();
            for(var i = 0; i < items.length; i++) {
                // Find a path
                var item = items[i];
                var node = this.getNodeById(item.id);
                // Add temporary search label.
                if (!node) {
                    alert("Missing node while searching: #" + item.id);
                }
                node.setSearchLabel(item.label);
                this._dirtyNodes.push(item.id);
                // Discuss - do we need it to be expandable??
                //node.showChildrenRecursive();
                while (node && !node.isRoot()) {
                    // Show the node and also enable all elements within it.
//                    node.show();
                    if (!node.isRoot()) {
                        nodesToExpand.push(node);
                    }
                    node = node.parent;
                }
            }
            

            // 2. Hide all nodes
            this.getRoot().getEl().children("li.ui-menu-item").hide();       // hide all

            // 3. Highlight results
            for(var i = 0; i < items.length; i++) {
                // Find a path
                var item = items[i];
                var node = this.getNodeById(item.id);
                // Add temporary search label.
                node.setSearchLabel(item.label);
                this._dirtyNodes.push(item.id);
            }

            // 4. Only show nodes that are found.
            for(var i = nodesToExpand.length - 1; i >= 0; i--) {
                nodesToExpand[i].visible = true; //show();
            }
            this.getRoot().showVisibleChildren();
            for(var i = nodesToExpand.length - 1; i >= 0; i--) {
                nodesToExpand[i].expand();
                nodesToExpand[i].updateIcon();
//                nodesToExpand[i].showVisibleChildren();
            }

            this.menu.refresh();
        } else {

            // Reset tree, showing nodes hidden by previous search.
            this.getRoot().disableSearchMode();
            this.getRoot().showVisibleChildren();
        }


        if (items.length == 0) {
            this.menu.element.addClass('EmptyList');
        } else {
            this.menu.element.removeClass('EmptyList');
        }
        if (newSuggestion) {
            this.rootElement.addClass('WithNewOption');
            if (this.overlay) {
                this.menu.element.parent().addClass("WithNewOption");
            }
            this.options.renderNew.apply(this, [this.newOption, newSuggestion]);
            this.newOption.data("item.lookup", newSuggestion);
        } else {
            this.rootElement.removeClass('WithNewOption');
            if (this.overlay) {
                this.menu.element.parent().removeClass("WithNewOption");
            }
            this.newOption.removeData("item.lookup");
        }
    },

    /**
     * Deletes the node and recurses children
     * @method _deleteNode
     * @private
     */
    _deleteNode: function(node) {
        // Remove all the child nodes first
        this.removeChildren(node);

        // Remove the node from the tree
        this.popNode(node);
    },

    /**
     * Clear search labels from any nodes marked as dirty
     */
    _clearSearchHighlighting: function() {
        for(var i = 0; i < this._dirtyNodes.length; i++) {
            var id = this._dirtyNodes[i];
            var node = this.getNodeById(id);
            if (node) {
                node.setSearchLabel(null);
            }
        }
        this._dirtyNodes = [];
    },

    /**
     * Dynamically load tree node.
     */
    dataLoader: function(node, callback) {
        var parentId = node.getId();
        var self = this;
        $.ajax({
            url: this.options.url,
            cache: true,
            ifModified: true,
            type: 'GET',
            data: { node: parentId, dynamic: true },
            dataType: 'json',
            success: function(data) {
                // Propagate all children
                var items = data.suggestions;
                var parent = self.getNodeById(parentId);
                for(var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var id = parseInt(item.id);
                    if (!self._nodes[id]) {
                        // Skip node if already exists.
                        var child = new treeCombo.TreeNode(item, parent);
                        self._nodes[id] = child;
                    } else {
                        // existing node. We're not in search mode, thus update it.
                        self._nodes[id].setLabel(item.label);
                    }
                }
            },
            complete: callback
        });
    },

    /**
     * Removes the node from the tree, preserving the child collection
     * to make it possible to insert the branch into another part of the
     * tree, or another tree.
     * @method popNode
     * @param {treeCombo.TreeNode} node to remove
     */
    popNode: function(node) {
        var p = node.parent;

        // Update the parent's collection of children
        var a = [];

        for (var i = 0, len = p.children.length; i < len; ++i) {
            if (p.children[i] != node) {
                a[a.length] = p.children[i];
            }
        }

        p.children = a;

        // reset the childrenRendered flag for the parent
        p.childrenRendered = false;

        // Update the sibling relationship
        if (node.previousSibling) {
            node.previousSibling.nextSibling = node.nextSibling;
        }

        if (node.nextSibling) {
            node.nextSibling.previousSibling = node.previousSibling;
        }

        if (this.currentFocus == node) {
            this.currentFocus = null;
        }
        if (this._currentlyHighlighted == node) {
            this._currentlyHighlighted = null;
        }

        node.parent = null;
        node.previousSibling = null;
        node.nextSibling = null;
        node.tree = null;

        // Update the tree's node collection
        delete this._nodes[node.getId()];
    },

    /**
     * Perform the expand animation if configured, or just show the
     * element if not configured or too many animations are in progress
     * @method animateExpand
     * @param el {HTMLElement} the element to animate
     * @param node {YAHOO.util.Node} the node that was expanded
     * @return {boolean} true if animation could be invoked, false otherwise
     */
    animateExpand: function(el, node) {

        if (this._expandAnim && this._animCount < this.maxAnim) {
            // this.locked = true;
            var tree = this;
            ++this._animCount;
            this._trigger("animStart", {
                "node": node,
                "type": "expand"
            });
            var a = $(el)[this._expandAnim](function() { tree.expandComplete(node); });
            return true;
        }

        return false;
    },

    /**
     * Perform the collapse animation if configured, or just show the
     * element if not configured or too many animations are in progress
     * @method animateCollapse
     * @param el {HTMLElement} the element to animate
     * @param node {YAHOO.util.Node} the node that was expanded
     * @return {boolean} true if animation could be invoked, false otherwise
     */
    animateCollapse: function(el, node) {

        if (this._collapseAnim && this._animCount < this.maxAnim) {
            // this.locked = true;
            var tree = this;
            ++this._animCount;
            this._trigger("animStart", {
                        "node": node,
                        "type": "collapse"
            });
            var a = $(el)[this._collapseAnim](function() { tree.collapseComplete(node); });

            return true;
        }

        return false;
    },

    /**
     * Function executed when the expand animation completes
     * @method expandComplete
     */
    expandComplete: function(node) {
        --this._animCount;
        this.fireEvent("animComplete", {
                "node": node,
                "type": "expand"
            });
        // this.locked = false;
    },

    /**
     * Function executed when the collapse animation completes
     * @method collapseComplete
     */
    collapseComplete: function(node) {
        --this._animCount;
        this.fireEvent("animComplete", {
                "node": node,
                "type": "collapse"
            });
        // this.locked = false;
    }

});

// Register treeSelectOne widget.
Selector.selectOne("treeSelectOne", $.ui.treeCombo);
// Register treeSelectMany widget.
Selector.selectMany("treeSelectMany", $.ui.treeCombo);

/**
 * A modification of base drop box
 * which allows next-prev navigation over the tree.
 */
$.widget("ui.treebox", $.ui.dropbox, {
    /**
     * TreeBox Constructor.
     */
	_create: function() {
        $.ui.dropbox.prototype._create.apply(this, arguments);
        if ($(this.element).parent().hasClass("Selector")) {
            // Only important for overlay mode.
            $(this.element).parent().addClass("TreeSelector");
        }
    },
 
    move: function(direction, edge, event) {
        if (!this.active) {
            // When no children available, select new option.
            if (this.mainList.find("li.ui-menu-item:visible").length == 0) {
                this.activate(event, this.newSuggestion);
            } else {
                this.activate(event, this.mainList.children(edge));
            }
            return;
        }
        // find out which node is that...
        // (only move through visible nodes)
        var item = this.active.data("item.lookup");
        var node = this.tree.getNodeById(item.id);
        var next = this.active[direction + "All"](".ui-menu-item:visible").eq(0);
        if (next.length) {
            this.activate(event, next);
        } else {
            this.activate(event, this.mainList.find(edge));
        }
    }
});

}(jQuery));