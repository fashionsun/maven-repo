/** Declare commons namespace */
if ($.gcommons == undefined) {
  $.gcommons = {};
}

/** Common JavaScript code. jQuery-dependent. */
function setDatepickerDefaults(lang) {
  /** Datepicker settings */
  var localized;
  if (lang != 'en') {
    localized = $.datepicker.regional[lang];
  } else {
    localized = {};
  }
  $.datepicker.setDefaults($.extend({
            useWeekRange: false,
            dateFormat: 'dd.mm.yy',
            changeMonth: false,
            changeYear: false,
            duration: '',
            showButtonPanel: false,
            showOtherMonths: true,
            selectOtherMonths: true
            }, localized));
}

/** Escape almost everything not conforming to jQuery selector syntax */
function jQuerySelectorEscape(str) {
    if (str) {
        return str.replace(/([ #;&,.+*~\':"!^$[\]()=>|\/@])/g, '\\$1')
    } else {
        return str;
    }
}

function generateBulkMessage(lang, pluralFormat, count) {
    var fmt = 'other';
    // 1. One
    if (count == 1) {
        fmt = 'one';
    }
    if (lang == 'ru') {
        // 2. Other
        if (count >= 10 && count <= 19) {
            fmt = 'other';
        // 3. Few
        } else if ((count % 10) >= 2 && (count % 10) <= 4) {
            fmt = 'few';
        }
    }

    // Has format?
    var i = pluralFormat.indexOf(fmt + '{');
    if (i < 0) {
        fmt = 'other';
        i = pluralFormat.indexOf(fmt + '{');
    }
    if (i >= 0) {
        var j = pluralFormat.indexOf('}', i + fmt.length + 1);
        var str = pluralFormat.substring(i + fmt.length + 1, j);
        return str.replace('#', '' + count);
    } else {
        alert('no suitable format ' + pluralFormat + '@' + fmt);
        return false;
    }
}

function openBulkConfirmDialog(lang, pluralFormat, selector, dialogId, messageId, arg1) {
    var cnt = $(selector).length;
    if (cnt == 0) return false;
    if (messageId) {
        var str = generateBulkMessage(lang, pluralFormat, cnt);
        if (arg1) {
            str = str.replace('[0]', arg1);
        }
        $('#' + messageId).html(str);
    }
    $('#' + dialogId).dialog('open');
    return false;
}

function displayAjaxFeedback (message) {
    var prevFeedback = $('#pageBody').children('.FeedBack');
    var template = $('#dynamicFeedbackTemplate').find ('.FeedBack');
    var feedback = template.clone();
    feedback.css ('zIndex', 5000);
    feedback.find ('.dynamicFeedbackMessage').html (message);
    feedback.appendTo('#pageBody');

    if (feedback.width() > $(window).width() / 2) {
        feedback.width($(window).width() / 2);
    }
    var left = Math.floor(($(window).width() - feedback.width())/2);
    feedback.css('left', left);
    feedback.css('display', 'none');
    feedback.find ('.Shadow').width(feedback.width()+4);
    feedback.find ('.Shadow').height(feedback.height()+3);
    prevFeedback.animate({"opacity": "hide"}, "slow");
    feedback.animate({"opacity": "show"}, "slow");
    prevFeedback.remove();
}

function getCookie(name) {
    if (document.cookie.length>0) {
        var start = document.cookie.indexOf(name + "=");
        if (start != -1) {
            start = start + name.length+1;
            var end = document.cookie.indexOf(";", start);
            if (end == -1) end = document.cookie.length;
            return document.cookie.substring(start, end);
        }
    }
    return "";
}

function setCookie(name, value, days, path) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    }
    document.cookie = name + "=" + value + expires + "; path=" + (path ? path : "/");
}

function delCookie(name) {
    setCookie(name, "", -1);
}

function formatHour(val) {
    var hours = parseInt(val);
    return '' + (hours > 24 ? hours - 24 : hours) + ':' + ((val - hours > 0) ? '30':'00');
}

function formatDate(dt) {
    var day = '' + dt.getDate();
    var month = '' + (dt.getMonth() + 1);
    var year = '' + dt.getFullYear();
    if (day.length == 1) day = '0' + day;
    if (month.length == 1) month = '0' + month;
    return day + '.' + month + '.' + year;
}

function html_entity_decode(str) {
    var temp = document.createElement("textarea");
    temp.innerHTML = str;
    return temp.value;
}


/**
 * Escape all characters according to JavaScript regexp rules.
 * @param text arbitrary text to be escaped.
 */
function escapeRegExp(text) {
    return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
}

/**
 * Very primitive HTML-encoding function.
 * @param text text to be escaped
 */
function escapeHTML(text) {
    return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}


/**
 * Case-insensitive.
 * @param text
 * @param substr
 */
function escapeHTMLAndHighlight(text, substr, hlTag) {
    if (!substr) {
        return escapeHTML(text);
    }
    if (!text) {
        return "";
    }
    var text2scan = text.toLowerCase();
    var lastPos = 0;
    var result = "";
    var i = text2scan.indexOf(substr);
    while (i >= 0) {
        if (i > lastPos) {
            result += escapeHTML(text.substring(lastPos, i));
        }
        result += ("<" + hlTag + ">");
        result += escapeHTML(text.substr(i, substr.length));
        result += ("</" + hlTag + ">");
        lastPos = i + substr.length;
        i = text2scan.indexOf(substr, i + substr.length);
    }
    if (lastPos < text.length) {
        result += escapeHTML(text.substr(lastPos));
    }
    return result;
}

function quickSearchTwisted(query, list, total, url, filtersForm, callback) {
    var params = $.param({q: query});
    if (filtersForm) {
        params += '&' + $(filtersForm).serialize();
    }
    $.ajax({
        url: url,
        data: params,
        dataType: 'json',
        type: 'POST',
        complete: function(xhr) {
        },
        success: function(data, text, xhr) {
          $(list).html(data.listContent);
          $(total).html(data.totalContent);
          callback(data);
        }
    });
}

function attachQuickSearchTwisted(input, list, total, url, defaultValue, filtersForm, callback) {
    if ($(input).val() == '') {
        $(input).val(defaultValue);
    }
    $(input).attr('autocomplete', 'off');
    $(input).focus(function() {
        if ($(input).val() == defaultValue) {
            $(input).val('');
        }
    });
    $(input).blur(function() {
        if ($(input).val() == '') {
            $(input).val(defaultValue);
        }
    });
    $(input).keydown(function(event) {
        if (event.keyCode == $.ui.keyCode.ESCAPE) {
            this.blur();
        }
    });
    $(input).keyup($.debounce(function(event) {
        var keyCode = $.ui.keyCode;
      switch(event.keyCode) {
        case keyCode.UP_ARROW:break;
        case keyCode.DOWN_ARROW:break;
        case keyCode.TAB:break;
        case keyCode.ESCAPE:break;
        case keyCode.PAGE_UP:break;
        case keyCode.PAGE_DOWN:break;
        case keyCode.LEFT_ARROW:break;
        case keyCode.RIGHT_ARROW:break;


        default:
            quickSearchTwisted($(input).val(), list, total, url, filtersForm, callback);
            break;
        }
    }, 300));


//        $(input).change($.throttle(function() {
//          console.log('throttle');
//          Gramant.quickSearchTwisted($(input).val(), list, total, url, filtersForm);
//        }, 700));
}

function setCookie(name, value, days, path) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    }
    document.cookie = name + "=" + value + expires + "; path=" + (path ? path : "/");
}

function delCookie(name) {
    setCookie(name, "", -1);
}

function go(link) {
    location.href = link;
    return false;
}

function changeRowsPerPage (url, num) {
    setCookie('rowsPerPage', num);
    var q = $("#quickSearch");
    if (q && (q.val() != q.attr("helperValue"))) {
        url = url + "&" + jQuery.param({q: q.val()});
    }
    go(url);
}

function applyTextInputHelpers() {
    $('input.withHelper').each(function(index, value) {
        if ($(this).val() == '') {
            $(value).val($(value).attr('helpervalue'));
            $(value).addClass('withHelperEnabled');
        }
    });
    $('input.withHelper').focus(function() {
        if ($(this).hasClass('withHelperEnabled')) {
            $(this).val('');
            $(this).removeClass('withHelperEnabled');
        }
    });
    $('input.withHelper').blur(function() {
        if ($(this).val() == '') {
            $(this).val($(this).attr('helpervalue'));
            $(this).addClass('withHelperEnabled');
        }
    });
    $('form').submit(function() {
        $(this).find('input.withHelperEnabled').each(function() {
            if ($(this).hasClass('withHelperEnabled')) {
                $(this).val('');
                $(this).removeClass('withHelperEnabled');
            }
        });
        return true;
    });

}

/** Based on UI 1.8.6 */
function applyAutocompleteHoveringPatch() {
    // ignore patch if using old layout... does not have ui.menu component.
    if ($.ui.menu) {
        $.ui.menu.prototype._activate = $.ui.menu.prototype.activate;
        $.ui.menu.prototype.activate = function(event, item) {
            this.deactivate();
            var _item = item.eq(0).children('a');
            if (this.hasScroll()) {
                var offset = _item.offset().top - this.element.offset().top,
                    scroll = this.element.attr("scrollTop"),
                    elementHeight = this.element.height();
                if (offset < 0) {
                    this.element.attr("scrollTop", scroll + offset);
                } else if (offset > elementHeight) {
                    this.element.attr("scrollTop", scroll + offset - elementHeight + _item.height());
                }
            }
            item.eq(0).addClass('ui-state-hover');
            this.active = _item.attr("id", "ui-active-menuitem").end();
            this._trigger("focus", event, { item: item });
        };
        $.ui.menu.prototype._deactivate = $.ui.menu.prototype.deactivate;
        $.ui.menu.prototype.deactivate = function() {
            if (!this.active) { return; }
            this.active.removeClass("ui-state-hover");
            this._deactivate();
        };
    }
}

/** Based on UI 1.8.6 */
function applyAutocompleteSpinnerPatch() {
    // ignore patch if using old layout... does not have ui.menu component.
    if ($.ui.autocomplete) {
        $.ui.autocomplete.prototype.__search = $.ui.autocomplete.prototype._search;
        $.ui.autocomplete.prototype._search = function(value) {
            this.__search(value);
            $(this.element).closest('.WidgetWithSpinner').addClass('WidgetLoading');
        };
        $.ui.autocomplete.prototype.__response = $.ui.autocomplete.prototype._response;
        $.ui.autocomplete.prototype._response = function(content) {
            this.__response(content);
            $(this.element).closest('.WidgetWithSpinner').removeClass('WidgetLoading');
        }
    }
}