import org.springframework.util.StringUtils
import com.gramant.gorm.NewHibernateCriteriaBuilder
import org.springframework.beans.BeanWrapperImpl
import com.gramant.utils.DeepCopyUtil
import org.codehaus.groovy.grails.commons.GrailsClass
import org.codehaus.groovy.grails.commons.GrailsClassUtils
import org.codehaus.groovy.grails.commons.GrailsApplication

/*
* GramantCommonsGrailsPlugin
*
* Copyright (c) 2010 Gramant. All Rights Reserved
*/

class GramantCommonsGrailsPlugin {
    
    // Maven artifact groupId
    def groupId = "gramant"
    
    // the plugin version
    def version = "1.0.14"

    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.3.2 > *"

    // the other plugins this plugin depends on
    def dependsOn = [ core: "1.1 > *", converters: "1.1 > *"]

    def loadAfter = ['hibernate']
    
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/index.gsp",
            "grails-app/views/error.gsp",
            "grails-app/views/layouts/test.gsp",
            "grails-app/controllers/com/gramant/common/test/TestWidgetController.groovy",
            "web-app/css/test/jquery/**",
            "web-app/js/test/jquery/**",
    ]

    def author = "Serge P. Nekoval"
    def authorEmail = "nekoval@gramant.ru"
    def title = "Internal utilities and UI."
    def description = '''\\
All sort of shared UI things for Gramant projects based on Grails.
'''

    // URL to the plugin's documentation
    def documentation = "https://confluence.gramant.ru/display/PRJ/Gramant+Commons"

    def doWithWebDescriptor = { xml ->
        xml << {
            'filter' {
                'filter-name'('imageFilter')
                'filter-class'('com.gramant.web.ImagePassThroughFilter')
                'init-param' {
                    'param-name'('baseURL')
                    'param-value'("/plugins/gramant-commons-${version}")
                }
            }

            ['jpg', 'png', 'ico', 'gif', 'css', 'js'].each { ext ->
                'filter-mapping' {
                    'filter-name'('imageFilter')
                    'url-pattern'('*.' + ext)
                }
            }
        }
    }

    /**
     * Adjust Spring configuration a bit.
     */
    def doWithSpring = {
        
    }

    /**
     * Register criteria methods, overriding ones provided by Hibernate Plugin.
     */
    static registerDynamicMethods(domainClass, application, ctx, sessionFactory) {
        def metaClass = domainClass.metaClass
        Class domainClassType = domainClass.clazz

        // Make sure HibernatePluginSupport lazy initializer is fired.
        metaClass.invokeStaticMethod(domainClassType, 'createCriteria', null)
        metaClass.static.createCriteria = {->
            new NewHibernateCriteriaBuilder(domainClassType, sessionFactory)
        }
        metaClass.static.withCriteria = {Closure callable ->
            new NewHibernateCriteriaBuilder(domainClassType, sessionFactory).invokeMethod("doCall", callable)
        }
        metaClass.static.withCriteria = {Map builderArgs, Closure callable ->
            def builder = new NewHibernateCriteriaBuilder(domainClassType, sessionFactory)
            def builderBean = new BeanWrapperImpl(builder)
            for (entry in builderArgs) {
                if (builderBean.isWritableProperty(entry.key)) {
                    builderBean.setPropertyValue(entry.key, entry.value)
                }
            }
            builder.invokeMethod("doCall", callable)
        }

        metaClass.copyAll = { Object[] args ->
            DeepCopyUtil.copyAll(application, delegate, args as String[])
        }
    }

    /**
     * Record create/update dates if necessary.
     * Register NewHibernateCriteriaBuilder as default builder.
     */
    def doWithDynamicMethods = { ctx ->
        def sessionFactory = ctx.getBean('sessionFactory')
        application.domainClasses.each { domainClass ->
            registerDynamicMethods(domainClass, application, ctx, sessionFactory)
            for (subClass in domainClass.subClasses) {
                registerDynamicMethods(subClass, application, ctx, sessionFactory)
            }
        }
    }

    def doWithApplicationContext = { applicationContext ->
        def listeners = applicationContext.sessionFactory.eventListeners
        if (applicationContext.customEventListeners) {
            applicationContext.customEventListeners.listenerMap.each { type, listener ->
                addEventTypeListener(listeners, listener, type)
            }
        }

        // Propagate service initialization config, ie init and destroy methods.
        // See http://www.bluetrainsoftware.com/2011/10/initializing-your-grails-beans.html
        forAllServices(application, 'init')
    }

    def forAllServices(GrailsApplication application, String methodName) {
        application.serviceClasses.each { GrailsClass gClass ->

            String scope = GrailsClassUtils.getStaticPropertyValue(gClass.clazz, "scope")

            if (!scope || scope == "singleton") {
                def serviceBean = application.mainContext.getBean(gClass.propertyName)

                if (serviceBean.metaClass.respondsTo(serviceBean, methodName)) {
                    serviceBean."$methodName"()
                }
            }
        }
    }

    def addEventTypeListener(listeners, listener, type) {
        def camelCaseType = type.tokenize('-').collect { it.capitalize() }.join('')
        def typeProperty = StringUtils.uncapitalize("${camelCaseType}EventListeners")
        def typeListeners = listeners."${typeProperty}"

        def expandedTypeListeners = new Object[typeListeners.length + 1]
        System.arraycopy(typeListeners, 0, expandedTypeListeners, 0, typeListeners.length)
        expandedTypeListeners[-1] = listener

        listeners."${typeProperty}" = expandedTypeListeners
    }

    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }
}
